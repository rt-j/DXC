import React, { Component } from 'react';

class ContactUs extends Component {
    render() {
        return (
            <div>
                
        <div class="Features-section paddingTB60 bg-pink ">
            
    <div class="container">
	<div class="row">
		<div class="col-md-12 site-heading ">
						<h3>Contact Us</h3>
						
						<div class="border"></div>
                        <br />
                <br />
					</div>
	</div>
	<div class="row">
						<div class="col-sm-6 col-md-3">
							<div class="col-md-12 feature-box">
								<span class="glyphicon glyphicon-cog icon"></span>
								<h3>EmailId</h3>
								<span>  <i class="fa fa-envelope fa-1x" aria-hidden="true"></i>	<p>university@dxc.com </p></span>

							</div>
						</div> 
						<div class="col-sm-6 col-md-3">
								<div class="col-md-12 feature-box">
								<span class="glyphicon glyphicon-cog icon"></span>
								<h3>Call Us At</h3>
								<span>  <i class="fa fa-volume-control-phone" aria-hidden="true"></i>	<p>99 656 88 999 </p></span>
							
							</div>
						</div> 
						
						<div class="col-sm-6 col-md-3">
								<div class="feature-box">
								<span class="glyphicon glyphicon-cog icon"></span>
								<h3>Address</h3>
								<span>  <i class="fa fa-map-o" aria-hidden="true"></i>	<h5>39/40 HP Avenue Banglore </h5></span>
								<div><p>Bangalore India</p></div>
							</div>
						</div> 
						
						
                            <br />
                            <br />
               
				    	</div>
                     </div>
                </div>

                
            </div>
        );
    }
}

export default ContactUs;