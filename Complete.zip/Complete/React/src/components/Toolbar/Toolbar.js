import React, { Component } from 'react';
import './Toolbar.css'
import DrawerToggleButton from '../SideDrawer/DrawerToggleButton';
import {
  BrowserRouter,
  Link,

} from 'react-router-dom';
class Toolbar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      displayMenu: false,
    };
    //this.drawerClickHandler=this.drawerClickHandler.bind(this)
    this.showDropdownMenu = this.showDropdownMenu.bind(this);
    this.hideDropdownMenu = this.hideDropdownMenu.bind(this);
    //this.linkClicked=this.linkClicked.bind(this);
  }
  showDropdownMenu(event) {
    event.preventDefault();
    this.setState({ displayMenu: true }, () => {
      document.addEventListener('click', this.hideDropdownMenu);
    });
  }

  hideDropdownMenu() {
    this.setState({ displayMenu: false }, () => {
      document.removeEventListener('click', this.hideDropdownMenu);
    });

  }
  /* linkClicked(){
   this.props.history.push(`/login`)
 }  */

  render() {
    return (
      <header className="toolbar">
        <nav className="toolbar__navigation">
          <div className="toolbar__toggle-button">
            <DrawerToggleButton click={this.props.drawerClickHandler}></DrawerToggleButton>
          </div>
          <div className="toolbar__logo">
            <div>DXC University</div>
          </div>
          <div className="spacer" />
          <div className="toolbar_navigation-items">
            <ul>
              <BrowserRouter>
                <li>
              <h4> <a href="/">Home</a></h4>
                </li>
                <li>
                <h4>  <a href="/aboutUs" >About</a></h4>
                </li>
                <li>
                <h4>  <a href="/contactUs" >Contact Us</a></h4>
                </li>
                
                <li>
                  <h4><a href="/adminLogin">Admin Login</a></h4>
                </li>
              </BrowserRouter>
              
            </ul>
          </div>
        </nav>
      </header>
      
    );
  }
}

export default Toolbar;