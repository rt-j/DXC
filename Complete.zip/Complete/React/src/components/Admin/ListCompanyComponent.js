import React, { Component } from 'react'
import AdminDataService from '../../service/AdminDataService';
import { BrowserRouter, } from 'react-router-dom';
import './Admin.css'
import './Table1.css'
 class ListCompanyComponent extends Component {

    constructor(props) {
        super(props)
        this.refreshCompany = this.refreshCompany.bind(this);
        this.deleteButtonClicked = this.deleteButtonClicked.bind(this);
        this.addCompanyCliked = this.addCompanyCliked.bind(this);
        this.placementClicked=this.placementClicked.bind(this);
        this.MarksClick=this.MarksClick.bind(this)

        this.addStudentCliked = this.addStudentCliked.bind(this);
        this.displayCompanyClicked=this.displayCompanyClicked.bind(this)
        this.addCompanyClicked=this.addCompanyClicked.bind(this)
        this.MarksClick = this.MarksClick.bind(this)
        this.displayStudentCliked=this.displayStudentCliked.bind(this)
        //this.drawerClickHandler=this.drawerClickHandler.bind(this)
        this.showDropdownMenu1 = this.showDropdownMenu1.bind(this);
        this.showDropdownMenu2 = this.showDropdownMenu2.bind(this);
        this.hideDropdownMenu1 = this.hideDropdownMenu1.bind(this);
        this.hideDropdownMenu2 = this.hideDropdownMenu2.bind(this);

        this.state = ({
            companies: [],
            message: ''
        })
    }
    showDropdownMenu1(event) {
        event.preventDefault();
        this.setState({ displayMenu1: true }, () => {
            document.addEventListener('click', this.hideDropdownMenu1);
        });
    }
    showDropdownMenu2(event) {
        event.preventDefault();
        this.setState({ displayMenu2: true }, () => {
            document.addEventListener('click', this.hideDropdownMenu2);
        });
    }
    
    hideDropdownMenu1() {
        this.setState({ displayMenu1: false }, () => {
            document.removeEventListener('click', this.hideDropdownMenu1);
        });
    
    }
    hideDropdownMenu2() {
        this.setState({ displayMenu2: false }, () => {
            document.removeEventListener('click', this.hideDropdownMenu2);
        });
    
    }
    displayCompanyClicked(){
        this.props.history.push(`/goToCompany`)
    }
    addCompanyClicked(){
        this.props.history.push(`addCompany`)
    }
    MarksClick() {
        this.props.history.push(`/addMarks`)
    }
    
    displayStudentCliked(){
        this.props.history.push(`/displayStudent`)
    }
    addStudentCliked() {
        this.props.history.push(`/addStudent`)
    }
    placementClicked() {
        this.props.history.push(`/adminPlacement`)
    }

    componentWillMount() {
        this.refreshCompany();
    }

    deleteButtonClicked(companyIdToDelete) {
        AdminDataService.deleteCompany(companyIdToDelete).then(
            response => {
                this.setState({ message: `Delete of student ${companyIdToDelete} Successful` })
                this.refreshCompany()
            }
        );
    }

    refreshCompany() {
        AdminDataService.getAllCompanies().then(
            response => {
                this.setState({
                    companies: response.data
                });
            }
        );
    }
    MarksClick(){
        this.props.history.push(`/addMarks`)
    }

   
    addCompanyCliked() {
        this.props.history.push(`/addCompany`)
    }
    placementClicked(){
        this.props.history.push(`/goToCompany`)
    }
    
    backClicked(){
        this.props.history.push(`/adminLoggedIn`)
    }
    render() {
        return (
            <main style={{ marginTop: '90px',marginLeft:'10%' ,marginRight:'10%'}}>
                <div>
                <button class="btn btn-warning" onClick={()=>this.backClicked()}>Back</button>
                <br/>
                <br/>
                </div>
              
            <div>
                <div className="table1">
                    {this.state.message && <div className="alert alert-success">{this.state.message}</div>}
                    <table className="customers">
                        <thead>
                            <tr>
                                <th >Company Id</th>
                                <th>Company Name</th>
                                <th>Compensation</th>
                                <th>Eligibility</th>
                                <th>Delete</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.companies.map(c =>
                                    <tr key={c.companyId}>
                                        <td>{c.companyId}</td>
                                        <td>{c.companyName}</td>
                                        <td>{c.compensation}</td>
                                        <td>{c.eligibility}</td>
                                      
                                        
                                        <td>
                                            <button className="btn btn-outline-dark" onClick={() => this.deleteButtonClicked(c.companyId)}>
                                                Delete
                                            </button>
                                        </td>
                                        
                                    </tr>)
                            }
                        </tbody>
                    </table>
                </div>
               
                
            </div>
        </main>
        )
    }
}
export default ListCompanyComponent
