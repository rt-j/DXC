import React, { Component } from 'react'
import './Admin.css'
import { Formik, Form, Field, ErrorMessage } from 'formik';
import AdminDataService from '../../service/AdminDataService';
import { BrowserRouter, } from 'react-router-dom';

 class StudentComponent extends Component {
    constructor(props) {

        super(props);
        this.state = ({
            studentId: this.props.match.params.studentId,
            studentName: '',
            course: '',
            email:''
            
            
        })
        this.onSubmit = this.onSubmit.bind(this)
        this.addStudentCliked = this.addStudentCliked.bind(this);
        this.displayCompanyClicked=this.displayCompanyClicked.bind(this)
        this.addCompanyClicked=this.addCompanyClicked.bind(this)
        this.MarksClick = this.MarksClick.bind(this)
        this.displayStudentCliked=this.displayStudentCliked.bind(this)
        //this.drawerClickHandler=this.drawerClickHandler.bind(this)
        this.showDropdownMenu1 = this.showDropdownMenu1.bind(this);
        this.showDropdownMenu2 = this.showDropdownMenu2.bind(this);
        this.hideDropdownMenu1 = this.hideDropdownMenu1.bind(this);
        this.hideDropdownMenu2 = this.hideDropdownMenu2.bind(this);
    }

    componentWillMount(){
         AdminDataService.getStudent(this.state.studentId).then(
             response=>{
                 this.setState({
                     studentName:response.data.studentName,
                     course:response.data.course,
                     email:response.data.email
                 })
             }
         )
     }
    onSubmit(student) {

            AdminDataService.updateStudent(student).then(response =>
                {this.props.history.push('/displayStudent')}
            )
        
    }
    showDropdownMenu1(event) {
        event.preventDefault();
        this.setState({ displayMenu1: true }, () => {
            document.addEventListener('click', this.hideDropdownMenu1);
        });
    }
    showDropdownMenu2(event) {
        event.preventDefault();
        this.setState({ displayMenu2: true }, () => {
            document.addEventListener('click', this.hideDropdownMenu2);
        });
    }
    
    hideDropdownMenu1() {
        this.setState({ displayMenu1: false }, () => {
            document.removeEventListener('click', this.hideDropdownMenu1);
        });
    
    }
    hideDropdownMenu2() {
        this.setState({ displayMenu2: false }, () => {
            document.removeEventListener('click', this.hideDropdownMenu2);
        });
    
    }
    displayCompanyClicked(){
        this.props.history.push(`/goToCompany`)
    }
    addCompanyClicked(){
        this.props.history.push(`/addCompany`)
    }
    MarksClick() {
        this.props.history.push(`/addMarks`)
    }
    
    displayStudentCliked(){
        this.props.history.push(`/displayStudent`)
    }
    addStudentCliked() {
        this.props.history.push(`/addStudent`)
    }
    placementClicked() {
        this.props.history.push(`/adminPlacement`)
    }

    validateStudentFrom(values) {
        let errors = {}
        if (!values.studentId) {
            errors.studentId = 'Enter student Id'
        }
        else if (!values.studentName) {
            errors.studentName = 'Enter student Name'
        }
        else if (!values.course) {
            errors.course = 'Enter Course'
        }
        else if (!values.email) {
            errors.email= 'Enter Email'
        }
       
       
        return errors
    }

    backClicked(){
        this.props.history.push(`/adminLoggedIn`)
    }

    render() {
        let { studentId, studentName, course,email} = this.state
        return (
            <main style={{ marginTop: '101px',marginLeft:'10%' ,marginRight:'40%'}}>
                 <div>
                <button class="btn btn-warning" onClick={()=>this.backClicked()}>Back</button>
                </div>
            <div>
                <h3  align='center'>Update Student</h3>
                <div  align='center' className="container">
                    <Formik
                        initialValues={{ studentId, studentName, course, email }}
                        enableReinitialize={true}
                        onSubmit={this.onSubmit}
                        validateOnChange={false}
                        validateOnBlur={false}
                        validate={this.validateStudentFrom}>
                        <Form>
                            <ErrorMessage name="studentId" component="div" className="alert alert-warning" />
                            <ErrorMessage name="studentName" component="div" className="alert alert-warning" />
                            <ErrorMessage name="course" component="div" className="alert alert-warning" />
                            <ErrorMessage name="email" component="div" className="alert alert-warning" />
                            <fieldset className="from-group">
                                                       <Field className="form-control" type="text" name="studentId" disabled={(this.state.studentId!=0)?true:false}  />
                            </fieldset>
                            <fieldset className="from-group">
                            <br/>
                               <br/>
                                <Field className="form-control" type="text" name="studentName" placeholder="Student Name"/>
                            </fieldset>
                            <fieldset className="from-group">
                            <br/>
                               <br/>
                                <Field className="form-control" type="text" name="course"placeholder="Course"/>
                            </fieldset>
                            <fieldset className="from-group">
                            <br/>
                               <br/>
                                <Field className="form-control" type="text" name="email"placeholder="E-Mail"/>
                            </fieldset>
                            <br/>
                               <br/>
                            <button className="btn btn-success" type="submit">Update</button>
                        </Form>
                    </Formik>
                </div>
            </div>
            </main>
        )
    }
}
export default StudentComponent