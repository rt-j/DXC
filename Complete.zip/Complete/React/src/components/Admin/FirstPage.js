import React, { Component } from 'react'
import AdminDataService from '../../service/AdminDataService';
import { BrowserRouter, } from 'react-router-dom';
//import 'bootstrap/dist/css/bootstrap.css';
import './Admin.css'
export default class FirstPage extends Component {

    constructor(props) {
        super(props)
        
        this.addStudentCliked = this.addStudentCliked.bind(this);
        this.displayCompanyClicked=this.displayCompanyClicked.bind(this)
        this.addCompanyClicked=this.addCompanyClicked.bind(this)
        this.MarksClick = this.MarksClick.bind(this)
        this.displayStudentCliked=this.displayStudentCliked.bind(this)
        //this.drawerClickHandler=this.drawerClickHandler.bind(this)
        this.showDropdownMenu1 = this.showDropdownMenu1.bind(this);
        this.showDropdownMenu2 = this.showDropdownMenu2.bind(this);
        this.hideDropdownMenu1 = this.hideDropdownMenu1.bind(this);
        this.hideDropdownMenu2 = this.hideDropdownMenu2.bind(this);
        //this.linkClicked=this.linkClicked.bind(this);

        this.state = ({
            students: [],
            message: ''
        })
    }


showDropdownMenu1(event) {
    event.preventDefault();
    this.setState({ displayMenu1: true }, () => {
        document.addEventListener('click', this.hideDropdownMenu1);
    });
}
showDropdownMenu2(event) {
    event.preventDefault();
    this.setState({ displayMenu2: true }, () => {
        document.addEventListener('click', this.hideDropdownMenu2);
    });
}

hideDropdownMenu1() {
    this.setState({ displayMenu1: false }, () => {
        document.removeEventListener('click', this.hideDropdownMenu1);
    });

}
hideDropdownMenu2() {
    this.setState({ displayMenu2: false }, () => {
        document.removeEventListener('click', this.hideDropdownMenu2);
    });

}
displayCompanyClicked(){
    this.props.history.push(`/goToCompany`)
}
addCompanyClicked(){
    this.props.history.push(`addCompany`)
}
MarksClick() {
    this.props.history.push(`/addMarks`)
}

displayStudentCliked(){
    this.props.history.push(`/displayStudent`)
}
addStudentCliked() {
    this.props.history.push(`/addStudent`)
}
placementClicked() {
    this.props.history.push(`/adminPlacement`)
}


render() {
    return (
        <main style={{ marginTop: '101px', marginLeft: '150px' }}>
               <div>
                
                <div class="Features-section paddingTB60 bg-pink ">
            <div class="container">
            <div class="row">
                <div class="col-md-12 site-heading ">
                                <h3>Welcome Admin</h3>
                                <br/>
                                <div class="border"></div>
                            </div>
            </div>
            <BrowserRouter>
            <div class="row">
               
                                <div class="col-sm-6 col-md-3">
                                    <div class="col-md-12 feature-box">
                                        <span class="glyphicon glyphicon-cog icon"></span>
                                        <h4>Add Student to StudentDB</h4>
                                        <p>Admin can add students to the datebase</p>
                                        
                                        <button className="button" class="btn btn-warning site-btn"  onClick={this.addStudentCliked}>Go</button>
                                      
                                            <br/>
                                    </div>
                                </div> 
                               
                                <div class="col-sm-6 col-md-3">
                                    <div class="col-md-12 feature-box">
                                        <span class="glyphicon glyphicon-cog icon"></span>
                                        <h4>Display the list of students </h4>
                                        <p>Admin can view all the students available in the database</p>
                                        
                                         <button className="button" class="btn btn-warning site-btn" onClick={this.displayStudentCliked} >Go</button>
                                      
        
                                    </div>
                                </div>
                               
                                <div class="col-sm-6 col-md-3">
                                        <div class="col-md-12 feature-box">
                                        <span class="glyphicon glyphicon-cog icon"></span>
                                        <h4>Add Marks to a student</h4>
                                        <p>Admin can add marks of a particular student  </p>
                                        
                                    <button className="side_Button" class="btn btn-warning site-btn" onClick={() => this.MarksClick()} >Go</button>
                                     </div>
                                </div> 
                                                             
                                <div class="col-sm-6 col-md-3">
                                        <div class="feature-box">
                                        <span class="glyphicon glyphicon-cog icon"></span>
                                        <h4>Add the company for placements</h4>
                                        <p>Admin can add companies available for the student to apply </p>
                                        <button type="button" class="btn btn-warning site-btn"onClick={this.addCompanyClicked}>Go</button>
                                    </div>
                                </div> 
                              
                               
                                <div class="col-sm-6 col-md-3">
                                        <div class="col-md-12 feature-box">
                                        <span class="glyphicon glyphicon-cog icon"></span>
                                        <h4>Display all the avalable companies</h4>
                                        <p> Admin can view all the companies available for the student to apply for placement</p>
                                        <button className="button" class="btn btn-warning site-btn" onClick={this.displayCompanyClicked} >Go</button>
                                         </div>
                                    </div>
                                   
                                    
                       
                                </div>
                                </BrowserRouter>

                             </div>
                        </div>
        
                        
                    </div>
                    <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                
                <br />
                <br />
       


            
        </main>
    )
}
}
