import React, { Component } from 'react'

import { Formik, Form, Field, ErrorMessage } from 'formik';
import AdminDataService from '../../service/AdminDataService';
import FirstPage from './FirstPage';
import { BrowserRouter, } from 'react-router-dom';
import './Admin.css'

 class AddStudent extends Component {
    constructor(props) {

        super(props);
        this.state = ({
            studentId: '',
            studentName: '',
            course: '',
            email:'',
            password: '',
            status:''

            
        })
        this.onSubmit = this.onSubmit.bind(this)
        this.addStudentCliked = this.addStudentCliked.bind(this);
        this.displayCompanyClicked=this.displayCompanyClicked.bind(this)
        this.addCompanyClicked=this.addCompanyClicked.bind(this)
        this.MarksClick = this.MarksClick.bind(this)
        this.displayStudentCliked=this.displayStudentCliked.bind(this)
        //this.drawerClickHandler=this.drawerClickHandler.bind(this)
        this.showDropdownMenu1 = this.showDropdownMenu1.bind(this);
        this.showDropdownMenu2 = this.showDropdownMenu2.bind(this);
        this.hideDropdownMenu1 = this.hideDropdownMenu1.bind(this);
        this.hideDropdownMenu2 = this.hideDropdownMenu2.bind(this);
        //this.linkClicked=this.linkClicked.bind(this);
    }

    onSubmit(student) {
        AdminDataService.saveStudent(student).then(response =>{
           this.setState({
               status:response.status
           })
            
            console.log(this.state.status)
            if(this.state.status==200){
                alert("Student Successfully Added")
                this.props.history.push(`/displayStudent`)
            }
            else{
                alert("Student with this Id already Exists")
                this.props.history.push(`/adminLoggedIn`)

            }
        })
       
   }
    showDropdownMenu1(event) {
        event.preventDefault();
        this.setState({ displayMenu1: true }, () => {
            document.addEventListener('click', this.hideDropdownMenu1);
        });
    }
    showDropdownMenu2(event) {
        event.preventDefault();
        this.setState({ displayMenu2: true }, () => {
            document.addEventListener('click', this.hideDropdownMenu2);
        });
    }
    
    hideDropdownMenu1() {
        this.setState({ displayMenu1: false }, () => {
            document.removeEventListener('click', this.hideDropdownMenu1);
        });
    
    }
    hideDropdownMenu2() {
        this.setState({ displayMenu2: false }, () => {
            document.removeEventListener('click', this.hideDropdownMenu2);
        });
    
    }
    displayCompanyClicked(){
        this.props.history.push(`/goToCompany`)
    }
    addCompanyClicked(){
        this.props.history.push(`/addCompany`)
    }
    
    MarksClick() {
        this.props.history.push(`/addMarks`)
    }
    
    displayStudentCliked(){
        this.props.history.push(`/displayStudent`)
    }
    addStudentCliked() {
        this.props.history.push(`/addStudent`)
    }
    placementClicked() {
        this.props.history.push(`/adminPlacement`)
    }

    validateStudentFrom(values) {
        let errors = {}
        if (!values.studentId) {
            errors.studentId = 'Enter student Id'
        }
        else if (!values.studentName) {
            errors.studentName = 'Enter student Name'
        }
        else if (!values.course) {
            errors.course = 'Enter Course'
        }
        else if (!values.email) {
            errors.email = 'Enter a Email Id'
        }
        else if (!values.password) {
            errors.password = 'Enter Password'
        }
       
        return errors
    }

    backClicked(){
        this.props.history.push(`/adminLoggedIn`)
    }

    render() {
        let { studentId, studentName, course,email, password } = this.state
        return (
            <main style={{ marginTop: '101px',marginLeft:'10%' ,marginRight:'40%'}}>
                <div>
                <button class="btn btn-warning"  onClick={()=>this.backClicked()}>Back</button>
                </div>
            <div>
                <h3  align='center'>Add Student</h3>
                <div className="container">
                    <Formik
                        initialValues={{ studentId, studentName, course,email, password }}
                        enableReinitialize={true}
                        onSubmit={this.onSubmit}
                        validateOnChange={false}
                        validateOnBlur={false}
                        validate={this.validateStudentFrom}>
                        <Form align="center">
                            <ErrorMessage name="studentId" component="div" className="alert alert-warning" />
                            <ErrorMessage name="studentName" component="div" className="alert alert-warning" />
                            <ErrorMessage name="course" component="div" className="alert alert-warning" />
                            <ErrorMessage name="email" component="div" className="alert alert-warning" />
                            <ErrorMessage name="password" component="div" className="alert alert-warning" />
                            <fieldset className="from-group">
                                <Field className="form-control" type="text" name="studentId"  placeholder="Student Id" />
                            </fieldset>
                            <fieldset className="from-group">
                               <br/>
                               <br/>
                                <Field className="form-control" type="text" name="studentName" placeholder="Student Name" />
                            </fieldset>
                            <fieldset className="from-group">
                            <br/>
                               <br/>
                                 <Field className="form-control" type="text" name="course" placeholder="Course"/>
                            </fieldset>
                            <fieldset className="from-group">
                            <br/>
                               <br/>
                                  <Field className="form-control" type="text" name="email" placeholder="E-mail" />
                            </fieldset>
                            <fieldset className="from-group">
                            <br/>
                               <br/>    
                                     <Field className="form-control" type="text" name="password" placeholder="Password" />
                            </fieldset>
                            <br/>
                               <br/>
                            <button className="btn btn-warning" type="submit">Add</button>
                        </Form>
                    </Formik>
                </div>
            </div>
            </main>
        )
    }
}
export default AddStudent