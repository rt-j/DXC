import React, { Component } from 'react'
import AdminDataService from '../../service/AdminDataService'
import { Formik, Form, ErrorMessage, Field } from 'formik'
import { BrowserRouter, } from 'react-router-dom';
import './Admin.css'
import {
    MDBContainer,
    MDBRow,
    MDBCol,
    MDBCard
  } from "mdbreact";
class AddMarks extends Component {
    constructor(props) {
        super(props)

        this.state = {
                 studentId:'',
                 subject_1:'',
                 subject_2:'',
                 subject_3:'',
                 subject_4:'',
                 subject_5:'',
                 subject_6:'',
                 status:''
        }
        this.submit=this.submit.bind(this)
        this.addStudentCliked = this.addStudentCliked.bind(this);
        this.displayCompanyClicked=this.displayCompanyClicked.bind(this)
        this.addCompanyClicked=this.addCompanyClicked.bind(this)
        this.MarksClick = this.MarksClick.bind(this)
        this.displayStudentCliked=this.displayStudentCliked.bind(this)
        //this.drawerClickHandler=this.drawerClickHandler.bind(this)
        this.showDropdownMenu1 = this.showDropdownMenu1.bind(this);
        this.showDropdownMenu2 = this.showDropdownMenu2.bind(this);
        this.hideDropdownMenu1 = this.hideDropdownMenu1.bind(this);
        this.hideDropdownMenu2 = this.hideDropdownMenu2.bind(this);
        this.backClicked=this.backClicked.bind(this)
    }
    validateMyForm(value){
        let errors={}
        if(!value.studentId){
            errors.productName='Enter a Name'
        }
         else if(!value.subject_1){
            errors.productName='Enter Mark'
        }
        else if(!value.subject_2){
            errors.productName='Enter Mark'
        }
        else if(!value.subject_3){
            errors.productName='Enter Mark'
        }
        else if(!value.subject_4){
            errors.productName='Enter Mark'
        }
        else if(!value.subject_5){
            errors.productName='Enter Mark'
        }
        else if(!value.subject_6){
            errors.productName='Enter Mark'
        }

        
    
        return errors
    }

    submit(marks){
        
        AdminDataService.addMarkstoStudent(marks.studentId,marks).then(response =>
            
           this.setState({
               status:response.status
           })
        )
        if(this.state.status==200){
            alert("Marks successfully Added")
            this.props.history.push(`/displayStudent`)
        }
        else{
            alert("Student with studentId "+marks.studentId+ " may not exists or marks  is already added")
            this.props.history.push(`/adminLogggedIn`)

        }
        

    }
    showDropdownMenu1(event) {
        event.preventDefault();
        this.setState({ displayMenu1: true }, () => {
            document.addEventListener('click', this.hideDropdownMenu1);
        });
    }
    showDropdownMenu2(event) {
        event.preventDefault();
        this.setState({ displayMenu2: true }, () => {
            document.addEventListener('click', this.hideDropdownMenu2);
        });
    }
    
    hideDropdownMenu1() {
        this.setState({ displayMenu1: false }, () => {
            document.removeEventListener('click', this.hideDropdownMenu1);
        });
    
    }
    hideDropdownMenu2() {
        this.setState({ displayMenu2: false }, () => {
            document.removeEventListener('click', this.hideDropdownMenu2);
        });
    
    }
    displayCompanyClicked(){
        this.props.history.push(`/goToCompany`)
    }
    addCompanyClicked(){
        this.props.history.push(`addCompany`)
    }
    MarksClick() {
        this.props.history.push(`/addMarks`)
    }
    
    displayStudentCliked(){
        this.props.history.push(`/displayStudent`)
    }
    addStudentCliked() {
        this.props.history.push(`/addStudent`)
    }
    placementClicked() {
        this.props.history.push(`/adminPlacement`)
    }

    backClicked(){
        this.props.history.push(`/adminLoggedIn`)
    }
    render() {
        let{studentId,subject_1,subject_2,subject_3,subject_4,subject_5,subject_6}=this.state
        return (
            <main style={{ marginTop: '101px',marginLeft:'10%' ,marginRight:'40%'}}>
               <div>
                <button class="btn btn-warning"onClick={()=>this.backClicked()}>Back</button>
                </div>
            <div>
                <h1 align='center'>Add Marks to a Student</h1>
                
                <Formik
                   initialValues={{studentId,subject_1,subject_2,subject_3,subject_4,subject_5,subject_6}} enableReinitialize={true}
                   onSubmit={this.submit}
                    validateOnChange={false}
                    validateOnBlur={false}
                    validate={this.validateMyForm}
                   >
                   
                   <Form align="center">
                       <ErrorMessage name="studentId" component="div" className="alert alert-danger"/>
                       <ErrorMessage name="subject_1" component="div" className="alert alert-danger"/>
                       <ErrorMessage name="subject_2" component="div" className="alert alert-danger"/>
                       <ErrorMessage name="subject_3" component="div" className="alert alert-danger"/>
                       <ErrorMessage name="subject_4" component="div" className="alert alert-danger"/>
                       <ErrorMessage name="subject_5" component="div" className="alert alert-danger"/>
                       <ErrorMessage name="subject_6" component="div" className="alert alert-danger"/>
                       <fieldset className="form-group">
                           <Field className="form-control" type="text" name="studentId" placeholder="Student-Id"></Field>
                       </fieldset>
                       <fieldset className="form-group">
                            <br/>
                            <br/>
                               <Field className="form-control" type="text" name="subject_1" placeholder="Electronic Engineering"></Field>
                       </fieldset>
                       <fieldset className="form-group">
                       <br/>
                            <br/>
                         <Field className="form-control" type="text" name="subject_2"placeholder="Basics Of Computer Programming" ></Field>
                       </fieldset>
                       <fieldset className="form-group">
                       <br/>
                            <br/>
                           <Field className="form-control" type="text" name="subject_3" placeholder="ThermoDynamics"></Field>
                       </fieldset>
                       <fieldset className="form-group">
                       <br/>
                            <br/>
                           <Field className="form-control" type="text" name="subject_4" placeholder="Engineering Mathematics"></Field>
                       </fieldset>
                       <fieldset className="form-group">
                       <br/>
                            <br/>
                           <Field className="form-control" type="text" name="subject_5"placeholder="Environmental Sciences" ></Field>
                       </fieldset>
                       <fieldset className="form-group">
                       <br/>
                            <br/>
                           <Field className="form-control" type="text" name="subject_6"placeholder="Placement Services" ></Field>
                       </fieldset>
                       <br/>
                            <br/>

                       <button className="btn btn-warning" type="submit">Add Marks</button>
                   </Form>
               </Formik>
  
            </div>
            <br/>
                            <br/>
                            <br/>
                            <br/>
                            <br/>
                            <br/>
            </main>
        )
    }
}

export default AddMarks
