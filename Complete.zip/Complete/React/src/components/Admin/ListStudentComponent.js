import React, { Component } from 'react'
import AdminDataService from '../../service/AdminDataService';
import { BrowserRouter, } from 'react-router-dom';
import './Admin.css'
import './Table1.css'
 class ListStudentComponent extends Component {

    constructor(props) {
        super(props)
        this.refreshStudent = this.refreshStudent.bind(this);
        this.deleteButtonClicked = this.deleteButtonClicked.bind(this);
        
        this.MarksClick=this.MarksClick.bind(this)
        this.updateButtonClicked=this.updateButtonClicked.bind(this)
        
        this.addStudentCliked = this.addStudentCliked.bind(this);
        this.displayCompanyClicked=this.displayCompanyClicked.bind(this)
        this.addCompanyClicked=this.addCompanyClicked.bind(this)
        this.MarksClick = this.MarksClick.bind(this)
        this.displayStudentCliked=this.displayStudentCliked.bind(this)
        //this.drawerClickHandler=this.drawerClickHandler.bind(this)
        this.showDropdownMenu1 = this.showDropdownMenu1.bind(this);
        this.showDropdownMenu2 = this.showDropdownMenu2.bind(this);
        this.hideDropdownMenu1 = this.hideDropdownMenu1.bind(this);
        this.hideDropdownMenu2 = this.hideDropdownMenu2.bind(this);

        this.state = ({
            students: [],
            message: ''
        })
    }

    componentWillMount() {
        this.refreshStudent();
    }

   

    refreshStudent() {
        AdminDataService.getAllStudents().then(
            response => {
                this.setState({
                    students: response.data
                });
            }
        );
    }
    showDropdownMenu1(event) {
        event.preventDefault();
        this.setState({ displayMenu1: true }, () => {
            document.addEventListener('click', this.hideDropdownMenu1);
        });
    }
    showDropdownMenu2(event) {
        event.preventDefault();
        this.setState({ displayMenu2: true }, () => {
            document.addEventListener('click', this.hideDropdownMenu2);
        });
    }
    
    hideDropdownMenu1() {
        this.setState({ displayMenu1: false }, () => {
            document.removeEventListener('click', this.hideDropdownMenu1);
        });
    
    }
    hideDropdownMenu2() {
        this.setState({ displayMenu2: false }, () => {
            document.removeEventListener('click', this.hideDropdownMenu2);
        });
    
    }

    deleteButtonClicked(studentIdToDelete) {
        AdminDataService.deleteStudent(studentIdToDelete).then(
            response => {
                this.setState({ message: `Delete of student ${studentIdToDelete} Successful` })
                this.refreshStudent()
            }
        );
    }
   
    
    updateButtonClicked(studentId){
        this.props.history.push(`/update/${studentId}`)
    }
    
    displayCompanyClicked(){
        this.props.history.push(`/goToCompany`)
    }
    addCompanyClicked(){
        this.props.history.push(`/addCompany`)
    }
    MarksClick() {
        this.props.history.push(`/addMarks`)
    }
    
    displayStudentCliked(){
        this.props.history.push(`/displayStudent`)
    }
    addStudentCliked() {
        this.props.history.push(`/addStudent`)
    }
    placementClicked() {
        this.props.history.push(`/adminPlacement`)
    }

    backClicked(){
        this.props.history.push(`/adminLoggedIn`)
    }
    render() {
        return (
            <main style={{ marginTop: '90px',marginLeft:'10%' ,marginRight:'10%'}}>
                 <div>
                <button class="btn btn-warning" onClick={()=>this.backClicked()}>Back</button>
                <br/>
                <br/>
                </div>
                
            <div>
                <div className="container">
                    {this.state.message && <div className="alert alert-success">{this.state.message}</div>}
                    <table className="table1">
                        <thead>
                            <tr>
                                <th>Student Id</th>
                                <th>Student Name</th>
                                <th>Course</th>
                                <th>Email</th>
                                <th>Update</th>
                                <th>Delete</th>
                                <th>Percentage</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.students.map(c =>
                                    <tr key={c.studentId}>
                                        <td>{c.studentId}</td>
                                        <td>{c.studentName}</td>
                                        <td>{c.course}</td>
                                        <td>{c.email}</td>                                                                           
                                        <td>
                                            <button className="btn btn-outline-dark" onClick={() => this.updateButtonClicked(c.studentId)}>
                                                Update
                                            </button>
                                        </td>
                                        
                                        <td>
                                            <button className="btn btn-outline-dark" onClick={() => this.deleteButtonClicked(c.studentId)}>
                                                Delete
                                            </button>
                                        </td>
                                        {/* {c.marks ? (c.marks.map(m=>
                                        <td>{m.percentage}</td>)):<td>0.0</td>} */}
                                        {c.marks.map(m=>
                                        m.percentage?(<td>{m.percentage}</td>):(<td>0.0</td>))}
                                    </tr>)
                            }
                        </tbody>
                    </table>
                </div>
                
            </div>
        </main>
        )
    }
}
export default ListStudentComponent
