import React, { Component } from 'react'
import './Admin.css'
import { Formik, Form, Field, ErrorMessage } from 'formik';
import AdminDataService from '../../service/AdminDataService';
import { BrowserRouter, } from 'react-router-dom';

 class CompanyComponent extends Component {
    constructor(props) {

        super(props);
        this.state = ({
            companyId: '',
            companyName: '',
            compensation: '',
            eligibility: '',
            
        })
        this.onSubmit = this.onSubmit.bind(this)
        this.addStudentCliked = this.addStudentCliked.bind(this);
        this.displayCompanyClicked=this.displayCompanyClicked.bind(this)
        this.addCompanyClicked=this.addCompanyClicked.bind(this)
        this.MarksClick = this.MarksClick.bind(this)
        this.displayStudentCliked=this.displayStudentCliked.bind(this)
        //this.drawerClickHandler=this.drawerClickHandler.bind(this)
        this.showDropdownMenu1 = this.showDropdownMenu1.bind(this);
        this.showDropdownMenu2 = this.showDropdownMenu2.bind(this);
        this.hideDropdownMenu1 = this.hideDropdownMenu1.bind(this);
        this.hideDropdownMenu2 = this.hideDropdownMenu2.bind(this);
    }

    onSubmit(company) {

        AdminDataService.saveCompany(company).then(response =>{
            this.setState({
                status:response.status
            })
            
        
        if(this.state.status==200){
            alert("Company Successfuly Added")
            this.props.history.push(`/goToCompany`)
        }
        else{
            alert("Company Already Exists")
            this.props.history.push(`/adminLoggedIn`)
        }
    })
}

    showDropdownMenu1(event) {
        event.preventDefault();
        this.setState({ displayMenu1: true }, () => {
            document.addEventListener('click', this.hideDropdownMenu1);
        });
    }
    showDropdownMenu2(event) {
        event.preventDefault();
        this.setState({ displayMenu2: true }, () => {
            document.addEventListener('click', this.hideDropdownMenu2);
        });
    }
    
    hideDropdownMenu1() {
        this.setState({ displayMenu1: false }, () => {
            document.removeEventListener('click', this.hideDropdownMenu1);
        });
    
    }
    hideDropdownMenu2() {
        this.setState({ displayMenu2: false }, () => {
            document.removeEventListener('click', this.hideDropdownMenu2);
        });
    
    }
    displayCompanyClicked(){
        this.props.history.push(`/goToCompany`)
    }
    addCompanyClicked(){
        this.props.history.push(`/addCompany`)
    }
    MarksClick() {
        this.props.history.push(`/addMarks`)
    }
    
    displayStudentCliked(){
        this.props.history.push(`/displayStudent`)
    }
    addStudentCliked() {
        this.props.history.push(`/addStudent`)
    }
    placementClicked() {
        this.props.history.push(`/adminPlacement`)
    }

    validateStudentFrom(values) {
        let errors = {}
        if (!values.companyId) {
            errors.companyId = 'Enter company Id'
        }
        else if (!values.companyName) {
            errors.companyName = 'Enter company Name'
        }
        else if (!values.compensation) {
            errors.compensation = 'Enter compensation'
        }
        else if (!values.eligibility) {
            errors.eligibility = 'Enter eligibility'
        }
       
        return errors
    }

    backClicked(){
        this.props.history.push(`/adminLoggedIn`)
    }
    render() {
        let { companyId, companyName, compensation, eligibility } = this.state
        return (
            <main style={{ marginTop: '101px',marginLeft:'10%' ,marginRight:'40%'}}>
               <div>
                <button class="btn btn-warning" onClick={()=>this.backClicked()}>Back</button>
                </div>
            <div>
                <h3 align='center'>Add Comapny</h3>
                <div className="container">
                    <Formik
                        initialValues={{ companyId, companyName, compensation, eligibility }}
                        enableReinitialize={true}
                        onSubmit={this.onSubmit}
                        validateOnChange={false}
                        validateOnBlur={false}
                        validate={this.validateStudentFrom}>
                        <Form align="center">
                            <ErrorMessage name="companyId" component="div" className="alert alert-warning" />
                            <ErrorMessage name="companyName" component="div" className="alert alert-warning" />
                            <ErrorMessage name="compensation" component="div" className="alert alert-warning" />
                            <ErrorMessage name="eligibility" component="div" className="alert alert-warning" />
                            <fieldset className="from-group">
                                <Field className="form-control" type="text" name="companyId" placeholder="Company Id" />
                            </fieldset>
                            <fieldset className="from-group">
                              <br/>
                              <br/>
                                <Field className="form-control" type="text" name="companyName" placeholder="Company Name" />
                            </fieldset>
                            <fieldset className="from-group">
                            <br/>
                              <br/>
                           <Field className="form-control" type="text" name="compensation"  placeholder="Compensation" />
                            </fieldset>
                            <fieldset className="from-group">
                            <br/>
                              <br/>
                      <Field className="form-control" type="text" name="eligibility" placeholder="Eligibility" />
                            </fieldset>
                            <br/>
                              <br/>


                            <button className="btn btn-warning" type="submit">Add</button>
                        </Form>
                    </Formik>
                </div>
            </div>
            </main>
        )
    }
}
export default CompanyComponent