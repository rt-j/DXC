import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import './Footer.css'


class Footer extends Component {
    render() {
        return (
            <div >
                 <br />
                <br />
                <br />
                
                <br />

                <br />
                <br />
                <br />
                <br />
                
                <br />
                <br />
                <div class="container"  style={{backgroundColor:"#000000" }} class="copyright" >
            <div class="row" >
                <div class="col-md-12 col-lg-4">
                    <div class="dk-footer-box-info">
                        <a href="index.html" class="footer-logo"/>
                            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAb1BMVEUAAAD////IyMgwMDB7e3thYWH7+/s4ODgpKSl4eHjNzc339/ejo6MWFhZtbW3a2tpnZ2eLi4vj4+NQUFCbm5vU1NTt7e2goKC3t7c+Pj5DQ0OVlZWxsbEMDAzAwMArKyuEhIQiIiIbGxtOTk5bW1vBp8S0AAAD0klEQVR4nO2c20LiMBBAKchNRQVREQVB+P9v3HVdd7l0JpMWnDSe80pDcihtkskkrRYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADAtzHqd6z0R96NrUavsNLzbmpFbsyGN95NrcqtUfDWu6GVeTYazr0bWp2ZSXDm3cw6mAy9G1mLsUHwxbuR9XgMCj56N7Em3aDhnXcT63IZEHzwbmBtBgHDvncD63OtCr56N+8UXCmCTR2Q7nOhGI69G3caJqJg03uKL+5Fw6530w7pXuwx3M4XpnJLQfDSVHox3w73Kz7fD1PStz22x2/BciPBcBAs+TZul4yKbL9MFdrlDZ1M14GC09Jy14FS66nwBLdPJXSEYPhRZ2CKVzY8vdKLzJXaTqd0gFzn71rVv1xZQONCKzBQ6zqt1g5arUUx1Yo+HF0+0S4v/1t7GxYT5TYeBzS28sUDuQf1NVT7t8OAhtLK4IzL0bBYyYUPrpTv9ypYi6ehEpLYD2g8ide9hCtxNVTG0rs9htxTWCI7voZyVGK7c9FQuujOUoWzYdGRiv8f9IlB7o6pBm9DsaNb/7tEHAEFuolEDOXx5ldAYxm6IHVDObr0N6DxLnzcN36/v6EYIfwMaIjDu+OhXaqGxb30DR/PmdhTyLGA9AzFm7gplOVQ6y1MwVB+EpdyT2F9CtMwFAO9o+JZ+ui1UYbyqGwjfqJFjtMzlN81Iub3TCKG8txB4qlhhvGLZuY3aSKG8Usu9vyiNAyL2Dyu94jvTsMwdvHaNDFMylCNhpagrcGlaRibQ2IIzyRmGFqUOMQ4NcSwJhjukv9zmP+7NP/+MHZMI62EJ2uY/7g0/7lF/vNDOVghsWmWYf5xmvxjbeIKmxIvta2sJWIopmWpMe9QwnRKhuLDpq5bmN81/obiLQysPVlvor+h+BQG1g+tT6K7oXiPgmvAerJXMob5r+OLyaaGXIy1+K0JGYoZeaZ8mq34vckYynN7W06UZa7vaignfVnz2gxpX56G4r8vIjdxmLBhT1kXjcgvvQ9N990MtXl9VI5waL7vZbjSikbmeetZtD6GM3X7THSu/kLbBu5hOBOHop9U2G/RkR2/3fB2FSpYbc9MayUcynA+w+PZTW8yUzqIL6rve2oNZ5PjN+v59j1tunts5+FNXX+ot3et9Tbfr7cbH8g7Mw3af1iR7PeQ5r8POPu93Nnvx8//TIXsz8XI/2yT7M+nyf+MIYNgs8+Jyv6sr/zPa8v+zL38z03M/uzLH3B+KQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADSTX7XfMHMN0vLEAAAAAElFTkSuQmCC" alt="footer_logo" class="img-fluid" style={{height:'150px'}}/>
                           
                        <p class="footer-info-text" style={{color:'white'}}>
                          DXC UNIVERSITY
                        </p>
                        <div class="footer-social-link">
                            <h3>Follow us</h3>
                            <ul>
                                <li>
                                    <a href="https://www.facebook.com/">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://www.twitter.com/">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://aboutme.google.com › referer=gplus">
                                        <i class="fa fa-google-plus"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://in.linkedin.com">
                                        <i class="fa fa-linkedin"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://www.instagram.com/?hl=en">
                                        <i class="fa fa-instagram"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="footer-awarad">
                        <img src="images/icon/best.png" alt=""/>
                        <p style={{color:'white'}}>Making Tomorrow Brighter </p>
                    </div>
                </div>
                <div class="col-md-12 col-lg-8">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="contact-us">
                                <div class="contact-icon">
                                    <i class="fa fa-map-o" aria-hidden="true" style={{Color:"#FEC931" }}></i>
                                </div>
                                <div class="contact-info">
                                    <h3 style={{color:'white'}}>Bangalore India</h3>
                                    <p style={{color:'white'}}>Hp Avenue</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="contact-us contact-us-last">
                                <div class="contact-icon">
                                    <i class="fa fa-volume-control-phone" aria-hidden="true"></i>
                                </div>
                                <div class="contact-info">
                                    <h3 style={{color:'white'}}>99 656 88 999</h3>
                                    <p style={{color:'white'}}>Give us a call</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 col-lg-6">
                            <div class="footer-widget footer-left-widget">
                                <div class="section-heading">
                                    <h3 style={{color:'black'}}>Useful Links</h3>
                                    <span class="animate-border border-black"></span>
                                </div>
                                <ul>
                                    <li>
                                        <a href="/aboutUs" style={{color:'white'}}>About us</a>
                                    </li>
                                    <li>
                                        <a href="#" style={{color:'white'}}>Services</a>
                                    </li>
                                    
                                    <li>
                                        <a href="#" style={{color:'white'}}>Our Team</a>
                                    </li>
                                </ul>
                                <ul>
                                    <li>
                                        <a href="/contactUs" style={{color:'white'}}>Contact us</a>
                                    </li>
                                    <li>
                                        <a href="#" style={{color:'white'}}>Projects</a>
                                    </li>
                                   
                                  
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-12 col-lg-6">
                            <div class="footer-widget">
                                <div class="section-heading">
                                    <h3>Subscribe</h3>
                                    <span class="animate-border border-white"></span>
                                </div>
                                <p style={{color:'white'}}>DXC Technology helps clients thrive on change.
                                     We have a clear and confident vision for navigating the future, and have met the challenges of innovation many times.
                                      We strive to support a culture of performance, matched with integrity. Our CLEAR Values guide our instincts and inform our actions.</p>
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <span>Copyright © 2019, All Right Reserved DXC University</span>
                    </div>
                    <div class="col-md-6">
                        <div class="copyright-menu">
                            <ul>
                                <li>
                                    <a href="/">Home</a>
                                </li>
                                <li>
                                    <a href="#">Terms</a>
                                </li>
                                <li>
                                    <a href="#">Privacy Policy</a>
                                </li>
                                <li>
                                    <a href="/contactUs">Contact</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
       
       </div>
        );
    }
}

export default Footer;