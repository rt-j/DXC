import React, { Component } from 'react';

class Home extends Component {
    render() {
        return (
        <main style={{marginTop:'101px'}}>
        <div class="image"> 
          <img src={require('./hqdefault.jpg')} height="500px" width="100%"></img>
          <h2>A Movie in the Park:<br />Kung Fu Panda</h2>
          </div> 
        </main>
        );
    }
}

export default Home;