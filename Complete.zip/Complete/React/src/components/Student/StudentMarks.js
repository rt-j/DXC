import React, { Component } from 'react';
import StudentDataService from '../../service/StudentDataService';
import { BrowserRouter, } from 'react-router-dom';

class StudentMarks extends Component {
    constructor(props) {
        super(props);
        this.state = {
            marks: [],
            studentId: this.props.match.params.studentId,
            marksAvailable: ''
        }
        this.applyForCompany = this.applyForCompany.bind(this)
        this.showAppliedCompany = this.showAppliedCompany.bind(this)
        this.showDropdownMenu = this.showDropdownMenu.bind(this);
        this.MarksClick = this.MarksClick.bind(this)
        this.hideDropdownMenu = this.hideDropdownMenu.bind(this);
        this.backClicked = this.backClicked.bind(this)
    }

    componentWillMount() {
        StudentDataService.getStudentMarks(this.state.studentId).then(
            response => {
                if (response.data != null) {
                    this.setState({
                        marks: response.data,
                        marksAvailable: 1

                    })
                }

                else {
                    alert("You Have no Marks")
                    this.setState({
                        marksAvailable: 0
                    })
                }
            })
    }
    applyForCompany(studentId) {
        this.props.history.push(`/student/applyCompany/${studentId}`)
    }
    showAppliedCompany(studentId) {
        this.props.history.push(`/student/showAppliedCompanies/${studentId}`)
    }

    MarksClick() {
        console.log(this.state.studentId)
        this.props.history.push(`/student/marks/${this.state.studentId}`)
    }
    profileClick() {
        this.props.history.push(`/student/${this.state.studentId}`)
    }
    showDropdownMenu(event) {
        event.preventDefault();
        this.setState({ displayMenu: true }, () => {
            document.addEventListener('click', this.hideDropdownMenu);
        });
    }
    hideDropdownMenu() {
        this.setState({ displayMenu: false }, () => {
            document.removeEventListener('click', this.hideDropdownMenu);
        });
    }

    backClicked(studentId) {
        this.props.history.push(`/student/${studentId}`)
    }
    render() {
        return (
            <main style={{ marginTop: '101px',marginLeft:'10%' ,marginRight:'40%'}} >

                <div>
                    <div>
                        <button class="btn btn-warning" onClick={() => this.backClicked(this.state.studentId)}>Back</button>
                    </div>


                    {this.state.marks ? (this.state.marks.map(product =>

                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="well">
                                        <h3 style={{ lineHeight: '1', color: 'black' }}><i class="fa fa-yelp fa-1x" style={{ lineHeight: '2', color: '#FEC931' }} /> Electronic Engineering:</h3>
                                        <h4 style={{ marginLeft: '5%', lineHeight: '1', color: 'black' }}>{product.subject_1}</h4>
                                        <br />
                                        <br />
                                        <h3 style={{ lineHeight: '1', color: 'black' }}><i class="fa fa-yelp fa-1x" style={{ lineHeight: '2', color: '#FEC931' }} /> Basics Of Computer Programming:</h3>
                                        <h4 style={{ marginLeft: '%5', lineHeight: '1', color: 'black' }}>{product.subject_2}</h4>
                                        <br />
                                        <br />
                                        <h3 style={{ lineHeight: '1', color: 'black' }}><i class="fa fa-yelp fa-1x" style={{ lineHeight: '2', color: '#FEC931' }}></i>ThermoDynamics: </h3>
                                        <h4 style={{ marginLeft: '5%', lineHeight: '1', color: 'black' }}>{product.subject_3}</h4>
                                        <br />
                                        <h3 style={{ lineHeight: '1', color: 'black' }}><i class="fa fa-yelp fa-1x" style={{ lineHeight: '2', color: '#FEC931' }} /> Engineering Mathematics:</h3>
                                        <h4 style={{ marginLeft: '5%', lineHeight: '1', color: 'black' }}>{product.subject_4}</h4>
                                        <br />
                                        <br />
                                        <h3 style={{ lineHeight: '1', color: 'black' }}><i class="fa fa-yelp fa-1x" style={{ lineHeight: '2', color: '#FEC931' }} /> Environmental Sciences:</h3>
                                        <h4 style={{ marginLeft: '%5', lineHeight: '1', color: 'black' }}>{product.subject_5}</h4>
                                        <br />
                                        <br />
                                        <h3 style={{ lineHeight: '1', color: 'black' }}><i class="fa fa-yelp fa-1x" style={{ lineHeight: '2', color: '#FEC931' }}></i>Placement Services: </h3>
                                        <h4 style={{ marginLeft: '5%', lineHeight: '1', color: 'black' }}>{product.subject_6}</h4>
                                        <br />
                                        <br />
                                        <h2 style={{ lineHeight: '1' }}><i class="fa fa-percent fa-1x" style={{ lineHeight: '2', color: '#FEC931' }}></i>Percentage:</h2>
                                        <h3 style={{ marginLeft: '5%', lineHeight: '1', color: 'black' }}>{product.percentage}</h3>
                                        <div className="whatever"></div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        )):<h1>Sorry, your marks is not yet entered</h1>}
                </div>


                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />

                <br />
                <br />


            </main>
        );
    }
}

export default StudentMarks;