import React, { Component } from 'react';
import './Student.css'
import { BrowserRouter, } from 'react-router-dom';
import StudentDataService from '../../service/StudentDataService';

class Student extends Component {
    constructor(props) {
        super(props);
        this.state = {
            students: [],
            studentId: this.props.match.params.studentId,
            studentName: '',
            course: '',
            email: ''
        }
        this.refreshStudent = this.refreshStudent.bind(this)
        this.applyForCompany = this.applyForCompany.bind(this)
        this.showAppliedCompany = this.showAppliedCompany.bind(this)
        this.showDropdownMenu = this.showDropdownMenu.bind(this);
        this.MarksClick=this.MarksClick.bind(this)
        this.hideDropdownMenu = this.hideDropdownMenu.bind(this);
    }
    showDropdownMenu(event) {
        event.preventDefault();
        this.setState({ displayMenu: true }, () => {
            document.addEventListener('click', this.hideDropdownMenu);
        });
    }
    hideDropdownMenu() {
        this.setState({ displayMenu: false }, () => {
            document.removeEventListener('click', this.hideDropdownMenu);
        });
    }
    componentWillMount() {
        this.refreshStudent();

    }
    refreshStudent() {
        StudentDataService.getStudentById(this.state.studentId).then(
            response => {
                console.log(response.data)
                this.setState({
                    studentId: response.data.studentId,
                    studentName: response.data.studentName,
                    course: response.data.course,
                    email: response.data.email

                })
                //console.log(this.state.students)
            })
    }

    applyForCompany(studentId) {
        this.props.history.push(`/student/applyCompany/${studentId}`)
    }
    showAppliedCompany(studentId) {
        this.props.history.push(`/student/showAppliedCompanies/${studentId}`)
    }

    MarksClick() {
        console.log(this.state.studentId)
        this.props.history.push(`/student/marks/${this.state.studentId}`)
    }
    profileClick() {
        this.props.history.push(`/student/${this.state.studentId}`)

    }
    render() {
        return (
         
            <main style={{ marginLeft:'200px', marginTop:'101px' }}>
                {this.state.students}
              
                <div>
                <div>
                
                <div class="Features-section paddingTB60 bg-pink ">
            <div class="container">
            <div class="row">
                <div class="col-md-12 site-heading ">
                                <h3>Welcome </h3>
                                <div class="border"></div>
                            </div>
            </div>
            <div class="row">
                                <div class="col-sm-6 col-md-3">
                                    <div class="col-md-12 feature-box">
                                        <span class="glyphicon glyphicon-cog icon"></span>
                                        <h4>Display Marks</h4>
                                        <p>View the marks which you have scored   </p>
                                        <button type="button" class="btn btn-warning site-btn" onClick={() => this.MarksClick()}>Go</button>
        
                                    </div>
                                </div> 
                                <div class="col-sm-6 col-md-3">
                                        <div class="feature-box">
                                        <span class="glyphicon glyphicon-cog icon"></span>
                                        <h4>Apply For Placements</h4>
                                        <p>Apply for the Companies available in your college </p>

                                        <button type="button" class="btn btn-warning site-btn" onClick={() => this.applyForCompany(this.state.studentId)}>Go</button>
                                    </div>
                                </div> 
                                <div class="col-sm-6 col-md-3">
                                        <div class="col-md-12 feature-box">
                                        <span class="glyphicon glyphicon-cog icon"></span>
                                        <h4>View Placements</h4>
                                        <p>View the Placements that you have applied</p>
                                        <button type="button" class="btn btn-warning site-btn" onClick={() => this.showAppliedCompany(this.state.studentId)}>Go</button>
                                    </div>
                                </div> 
                                
                               
                               
                                    <br />
                
                                
                                    <br />
                       
                                </div>
                             </div>
                        </div>
        
                        
                    </div>
                    <br />
                <br />
                <br />
                <br />
                <br />
              
              
<div class="card-body">
    <div class="row">
        <div class="col-sm-6">
            <div class="well">
            <h3 style={{lineHeight:'1',color:'black'}}><i class="fa fa-user fa-1x" style={{lineHeight:'2',color:'#FEC931'}}></i>Student Name: </h3>
                <h4 style={{marginLeft:'5%',lineHeight:'1',color:'black'}}>{this.state.studentName}</h4>
                <br />
                <br />
                <h3 style={{lineHeight:'1',color:'black'}}><i class="fa fa-home fa-1x" style={{lineHeight:"6%",color:'#FEC931'}}/> Student ID:</h3>               
                <h4 style={{marginLeft:'5%',lineHeight:'1',color:'black'}}>{this.state.studentId} </h4>
                <br />
                <br />
                <h3 style={{lineHeight:'1',color:'black'}}><i class="fa fa-envelope fa-1x" style={{lineHeight:"6%",color:'#FEC931'}}/> Email-Id</h3>
                <h4 style={{marginLeft:'%5',lineHeight:'1',color:'black'}}>{this.state.email}</h4>
                
                <br />
                <br />
                <h3 style={{lineHeight:'1'}}><i class="fa fa-yelp fa-1x" style={{lineHeight:'2',color:'#FEC931'}}></i>Course:</h3>
                <h4 style={{marginLeft:'5%',lineHeight:'1',color:'black'}}>{this.state.course}</h4>
            </div>
        </div>
      
    </div>
    
</div>

               
               
                </div>
               
       
                
               
            </main>
        );
    }

}

export default Student;