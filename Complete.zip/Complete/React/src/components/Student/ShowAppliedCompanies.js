import React, { Component } from 'react'
import StudentDataService from '../../service/StudentDataService';
import { BrowserRouter, } from 'react-router-dom';
import '../Admin/Table1.css'
class ShowAppliedCompanies extends Component {
    constructor(props) {
        super(props)

        this.state = {
                 studentId:this.props.match.params.studentId,
                 appliedCompanies:[]
        }
        this.showApplied=this.showApplied.bind(this);
        this.deleteButtonClicked=this.deleteButtonClicked.bind(this)
        this.applyForCompany = this.applyForCompany.bind(this)
        this.showAppliedCompany = this.showAppliedCompany.bind(this)
        this.showDropdownMenu = this.showDropdownMenu.bind(this);
        this.MarksClick=this.MarksClick.bind(this)
        this.hideDropdownMenu = this.hideDropdownMenu.bind(this);
    }
    componentWillMount(){
        this.showApplied();
    }

    showApplied(){
        StudentDataService.showApplied(this.state.studentId).then(
            response=>{
                console.log(response.data)
                this.setState({
                    appliedCompanies:response.data
                })
            }
        )
    }
    deleteButtonClicked(companyId){
        console.log(companyId)
        StudentDataService.removeCompany(companyId,this.state.studentId).then(
            response=>{
                this.showApplied()
            })
    }
    applyForCompany(studentId) {
        this.props.history.push(`/student/applyCompany/${studentId}`)
    }
    showAppliedCompany(studentId) {
        this.props.history.push(`/student/showAppliedCompanies/${studentId}`)
    }

    MarksClick() {
        console.log(this.state.studentId)
        this.props.history.push(`/student/marks/${this.state.studentId}`)
    }
    profileClick() {
        this.props.history.push(`/student/${this.state.studentId}`)
    }
    showDropdownMenu(event) {
        event.preventDefault();
        this.setState({ displayMenu: true }, () => {
            document.addEventListener('click', this.hideDropdownMenu);
        });
    }
    hideDropdownMenu() {
        this.setState({ displayMenu: false }, () => {
            document.removeEventListener('click', this.hideDropdownMenu);
        });
    }
    backClicked(studentId){
        this.props.history.push(`/student/${studentId}`)
    }
    render() {
        return (
            <main style={{ marginTop: '101px',marginLeft:'10%' ,marginRight:'40%'}}>
               <div>
                <button class="btn btn-warning" onClick={()=>this.backClicked(this.state.studentId)}>Back</button>
                <br/>
                <br/>
                </div>
            <div>
                 <table className="table1">
                         <thead>
                             <tr>
                             <th>companyId</th>
                             <th>companyName</th>
                             <th>compensation</th>
                             <th>Remove</th>
                             </tr>
                         </thead>
                         <tbody>
                             {this.state.appliedCompanies.map(pl=>
                             <tr key={pl.companyId}>
                             <td>{pl.companyId}</td>
                             <td>{pl.companyName}</td>
                             <td>{pl.compensation}</td>
                             <td><button className="btn btn-outline-dark" onClick={() => this.deleteButtonClicked(pl.companyId)} >Remove</button></td>
                             </tr>
                             )}
                                    </tbody>                         
                    </table>

            </div>
            </main>
        )
    }
}

export default ShowAppliedCompanies
