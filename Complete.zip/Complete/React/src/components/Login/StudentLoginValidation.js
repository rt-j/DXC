import React, { Component } from 'react';
import './StudentLoginValidation.css'
import 'bootstrap/dist/css/bootstrap.css';
import { Formik, Form, Field, ErrorMessage } from 'formik'
import StudentLoginCheck from '../../service/StudentLoginCheck';
import AboutUs from '../AboutUs';
import StudentDataService from '../../service/StudentDataService';
import ContactUs from '../ContactUs';

class StudentLoginValidation extends Component {
    constructor(props) {
        super(props);
        this.state = {
            studentId: '',
            studentName: '',
            password: '',
            status:'',
            message:''
            
            
        } 
        this.handleSubmit = this.handleSubmit.bind(this)
        this.handleChange = this.handleChange.bind(this)
        this.forgotPassword=this.forgotPassword.bind(this)
    }
    handleChange(e){
        console.log(e)
       // e.preventDefault()
        this.setState({
            studentId:e
        })
    }
    handleSubmit(value){
        StudentLoginCheck.getCheck(value.studentId,value.studentName,value.password).then(
            response=>{
                this.setState({
                    status:response.status,
                })
                if(this.state.status==200){
                    this.props.history.push(`/student/${value.studentId}`)
                }
                else{
                   this.setState({
                       message:"Wrong Credentials"
                   })
                    this.props.history.push(`/studentlogin`)
                }

            }
       
        )
    
    }
    
    validateLoginForm(values) {
        let errors = {}
        if (!values.studentId) {
            errors.studentId = 'enter a studentId'
        }
        else if (!values.studentName) {
            errors.studentName = 'enter a studentname'
        }
        else if (!values.password) {
            errors.password = 'enter a password'
        }
        

        return errors
    }
    forgotPassword(){
        var n1= parseInt(prompt("Enter the studentId"))
       StudentDataService.forgotPassword(n1).then(response=>{
        this.setState({
            status:response.status
        })
         
         console.log(this.state.status)
         if(this.state.status==200){
             alert("Email with your password has been sent")
             this.props.history.push(`/`)
         }
         else{
             alert("There is no password for this studentId")
             this.props.history.push(`/`)

         }
     }
        
    

         )  }

    render(){ let { studentId, studentName, password} = this.state
        
    return (
        
        <main  className="anything">
        <div >
            <div className="container">
            <div class="d-flex justify-content-center h-100">
    <div class="card" style={{marginTop:'10px',marginLeft:'70%'}}>
        <div class="card-header">
        <div class="d-flex justify-content-end social_icon">
            
            </div>
            <h3>Sign In</h3>
            <div class="d-flex justify-content-end social_icon">
            </div>
        </div>
        <div class="card-body">
        <Formik
                    initialValues={{ studentId, studentName, password }}
                    enableReinitialize={true}
                    onSubmit={this.handleSubmit}
                    validateOnChange={false}
                    validateOnBlur={false}
                    validate={this.validateLoginForm}>
                        <Form >
                        <ErrorMessage name="studentId" component="div" className="alert alert-warning" />
                        <ErrorMessage name="studentName" component="div" className="alert alert-warning" />
                        <ErrorMessage name="password" component="div" className="alert alert-warning" />
    
                <div class="input-group form-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-user"></i></span>
                    </div>
                    <Field className="form-control input_id" type="text" name="studentId" placeholder="Student Id"  />
                    
                </div>
                
                <div class="input-group form-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-user"></i></span>
                    </div>
                    <Field className="form-control input_name" type="text" name="studentName"placeholder="Student Name" />
                    
                </div>
                <div class="input-group form-group">
                    <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fa fa-key"></i></span>
                    </div>
                            <Field className="form-control input_pass" type="password" name="password"  placeholder="password" />
                </div>
                <div class="row align-items-center remember">
                    <input type="button"   class="btn btn-warning" onClick={()=>this.forgotPassword()}/>Forgot Password
                </div>
                <div class="form-group">
                        <button className="btn btn-warning" type="submit"><h5>Login</h5></button>
                       
           
                </div>
                
        
        </Form>
            </Formik>
            </div>
        
    </div>
</div>
               
            </div>
            
            <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                
                <br />
                <br />
                <AboutUs/>
                <br/>
                <br/>
                <br/>
                <br/>
                <ContactUs/>
                
        </div>
    </main>
    );
}
}
export default StudentLoginValidation;