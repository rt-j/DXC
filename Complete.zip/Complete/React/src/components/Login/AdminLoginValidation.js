
    import React, { Component } from 'react';
    import './AdminValidation.css'
    //import 'bootstrap/dist/css/bootstrap.css';
    import { Formik, Form, Field, ErrorMessage } from 'formik'
    
    class AdminLoginValidation extends Component {
        constructor(props) {
            super(props);
            this.state = {
                adminId: '',
                adminName: '',
                password: '',
                message:''
                
                
            } 
            this.onSubmit = this.onSubmit.bind(this)
        }
        onSubmit(value) {
           if(value.adminId==1 && value.adminName=="Admin" && value.password=="1234"){
                this.props.history.push("/adminLoggedIn")
            }
            else{
                this.setState({
                    message:'No Entry'
                })
            }

        }
        validateLoginForm(values) {
            let errors = {}
            if (!values.adminId) {
                errors.adminId = 'enter AdminId'
            }
            else if (!values.adminName) {
                errors.adminName = 'enter a Adminname'
            }
            else if (!values.password) {
                errors.password = 'enter a password'
            }
            
    
            return errors
        }
    
        render(){ let { adminId, adminName, password} = this.state
        
        return (
            <main  className="something">
            <div>
                <div className="container">
                <div class="d-flex justify-content-center h-100">
		<div class="card" style={{marginTop:'202px',marginLeft:'150px'}}>
			<div class="card-header">
            <div class="d-flex justify-content-end social_icon">
				
				</div>
				<h3>Sign In</h3>
				<div class="d-flex justify-content-end social_icon">
				</div>
			</div>
            <div class="card-body">
            <Formik
                        initialValues={{ adminId, adminName, password }}
                        enableReinitialize={true}
                        onSubmit={this.onSubmit}
                        validateOnChange={false}
                        validateOnBlur={false}
                        validate={this.validateLoginForm}>
                            <Form >
                            <ErrorMessage name="adminId" component="div" className="alert alert-warning" />
                            <ErrorMessage name="adminName" component="div" className="alert alert-warning" />
                            <ErrorMessage name="password" component="div" className="alert alert-warning" />
		
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fa fa-user"></i></span>
						</div>
                        <Field className="form-control input_id" type="text" name="adminId" placeholder="Admin Id" />
						
					</div>
                    
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fa fa-user"></i></span>
						</div>
                        <Field className="form-control input_name" type="text" name="adminName"placeholder="Admin Name" />
						
					</div>
					<div class="input-group form-group">
						<div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-key"></i></span>
						</div>
                                <Field className="form-control input_pass" type="password" name="password"  placeholder="password" />
					</div>
					
					<div class="form-group">
                            <button className="btn btn-warning" type="submit">Login</button>
					</div>
               
			
            </Form>
                </Formik>
                </div>
			
		</div>
	</div>
                   
                </div>
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                
                <br />
                <br />
       
            </div>
        </main>
        );
    }
    }
export default AdminLoginValidation;