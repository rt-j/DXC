import React, { Component } from 'react';

class AboutUs extends Component {
    render() {
        return (
            <div>
				<br/>
				<br/>
				<br/>
				<br/>
				<br/>
				<br/>
				<br/>
				<br/>
                
        <div class="Features-section paddingTB60 bg-pink ">
            
    <div class="container">
	<div class="row">
		<div class="col-md-12 site-heading ">
						<h3>About Us</h3>
						
						<div class="border"></div>
                        <br />
                <br />
					</div>
	</div>
	<div class="row">
						<div class="col-sm-6 col-md-3">
							<div class="col-md-12 feature-box">
								<span class="glyphicon glyphicon-cog icon"></span>
								<h4>Among the world's best</h4>
								<p>Our Engineering – Mineral and Mining discipline has ranked at top 30 in the world, for the third consecutive year, and our Nursing discipline is ranked in the world's top 50 in the 2019 QS World University Rankings by Subject list. The University has a total of 10 subjects ranked in the world’s top 200.
                                   </p>

							</div>
						</div> 
						<div class="col-sm-6 col-md-3">
								<div class="col-md-12 feature-box">
								<span class="glyphicon glyphicon-cog icon"></span>
								<h4>Student success</h4>
								<p>Each year, students from across our five faculties are recognised and awarded for their outstanding achievements. We are proud to share their successes. </p>
							</div>
						</div> 
						
						<div class="col-sm-6 col-md-3">
								<div class="feature-box">
								<span class="glyphicon glyphicon-cog icon"></span>
								<h4>Student Services</h4>
								<p>As well as providing a world-class education, we also offer a range of other services including careers advice and access to Student Central and the prestigious Senate House Library. The University also manages a range of high-quality student accommodation in central London where students can mix with others from across a range of member institutions.</p>
							</div>
						</div> 
						
						
                            <br />
                            <br />
               
				    	</div>
                     </div>
                </div>

                
            </div>
        );
    }
}

export default AboutUs;