import axios from 'axios'
const STUDENT_API_URL='http://localhost:8001/student'
const PLACEMENT_API_URL='http://localhost:8001/placement'
const MARKS_API_URL='http://localhost:8001/marks'

class StudentDataService
{
    
    getStudentById(studentId)
    {
        console.log("axios")
        return axios.get(`${STUDENT_API_URL}/${studentId}`)
    }
    showAllCompanies()
    {
        return axios.get(`${PLACEMENT_API_URL}`)
    }

    applyforCompany(companyId,studentId){
        return axios.post(`${PLACEMENT_API_URL}/companyId/${companyId}/studentId/${studentId}`)
    }

    removeCompany(companyId,studentId){
        return axios.delete(`${PLACEMENT_API_URL}/companyId/${companyId}/studentId/${studentId}`)
    }
    showApplied(studentId){
        return axios.get(`${PLACEMENT_API_URL}/studentId/${studentId}`)
    }

    getStudentMarks(studentId){
        return axios.get(`${MARKS_API_URL}/studentId/${studentId}`)
    }
    forgotPassword(studentId){
        return axios.get(`${STUDENT_API_URL}/sendPassword/studentId/${studentId}`)
    }
}
export default new StudentDataService()