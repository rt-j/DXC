import axios from 'axios'
const url="http://localhost:8001/student"
class StudentLoginCheck{
    getCheck(id,name,password){
        return axios.get(`${url}/check/${id}/${name}/${password}`)
    }
}export default new StudentLoginCheck()