import axios from 'axios'
const MARKS_API_URL='http://localhost:8001/marks'
const STUDENT_API_URL = "http://localhost:8001/student"
const COMPANY_API_URL = "http://localhost:8001/placement"

class AdminDataService {
    addMarkstoStudent(studentId,marks){
        return axios.post(`${MARKS_API_URL}/studentId/${studentId}`,marks);
    }

    updateMarkstoStudent(studentId,marks){
        return axios.put(`${MARKS_API_URL}/studentId/${studentId}`,marks);
    }

    getAllStudents() {
        return axios.get(`${STUDENT_API_URL}`);
    }
    deleteStudent(studentId) {
        return axios.delete(`${STUDENT_API_URL}/${studentId}`);
    }
    getStudent(studentId) {
        return axios.get(`${STUDENT_API_URL}/${studentId}`);
    }
    updateStudent(student) {
        return axios.put(`${STUDENT_API_URL}`, student);
    }
    saveStudent(student) {
        return axios.post(`${STUDENT_API_URL}/`, student);
    }
    deleteCompany(companyId) {
        return axios.delete(`${COMPANY_API_URL}/companyId/${companyId}`)
    }
    getAllCompanies() {
        return axios.get(`${COMPANY_API_URL}`);
    }

    getCompany(companyId) {
        return axios.get(`${COMPANY_API_URL}/companyId/${companyId}`);
    }

    saveCompany(company) {
        return axios.post(`${COMPANY_API_URL}/`, company);
    }
}

export default new AdminDataService()
