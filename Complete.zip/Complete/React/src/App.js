import React, { Component } from 'react';
import Toolbar from './components/Toolbar/Toolbar';
import SideDrawer from './components/SideDrawer/SideDrawer';
import Backdrop from './components/Backdrop/Backdrop';
import StudentLoginValidation from './components/Login/StudentLoginValidation';
import {Switch,Route} from 'react-router-dom'
import {BrowserRouter as Router} from 'react-router-dom'
import Student from './components/Student/Student';
//import AdminLoginValidation from './components/Login/AdminLoginValidation';
//import Home from './components/Home/Home';
import ApplyForCompany from './components/Student/ApplyForCompany';
import ShowAppliedCompanies from './components/Student/ShowAppliedCompanies';
import AddMarks from './components/Admin/AddMarks';
import ListStudentComponent from './components/Admin/ListStudentComponent';
import StudentComponent from './components/Admin/StudentComponent';
import AdminLoginValidation from './components/Login/AdminLoginValidation';
import CompanyComponent from './components/Admin/CompanyComponent';
import StudentMarks from './components/Student/StudentMarks';
import ListCompanyComponent from './components/Admin/ListCompanyComponent';
import AddStudent from './components/Admin/AddStudent';
import FirstPage from './components/Admin/FirstPage';
import Footer from './components/Footer';
import AboutUs from './components/AboutUs';
import ContactUs from './components/ContactUs';



class App extends Component {
  constructor(props) {
    super(props);
    this.state={
      sideDrawerOpen:false
    }
    this.drawerToggleClickHandler=this.drawerToggleClickHandler.bind(this)
    this.backdropClickHandler=this.backdropClickHandler.bind(this)
  }
  drawerToggleClickHandler(){
    this.setState((prevState)=>{
      return {sideDrawerOpen:!prevState.sideDrawerOpen}
    })
  }
  backdropClickHandler(){
    this.setState({
      sideDrawerOpen:false
    })
  }
  
  render() {
    //let sideDrawer;
    let backdrop;

    if(this.state.sideDrawerOpen){
      //sideDrawer=<SideDrawer/>
      backdrop=<Backdrop click={()=>this.backdropClickHandler()}/>
    }
    return (
      <div style={{height:'100%'}}>
         <Toolbar  drawerClickHandler={()=>this.drawerToggleClickHandler()}></Toolbar> 
        <SideDrawer show={this.state.sideDrawerOpen}></SideDrawer> 
        {backdrop} 
         <Router>
          <Switch>
            <Route exact path="/aboutUs" component={AboutUs}/>
            <Route exact path="/contactUs" component={ContactUs}/>
            <Route exact path="/" component={StudentLoginValidation}/>
            <Route exact path="/studentlogin" component={StudentLoginValidation}/>
            <Route exact path="/adminlogin" component={AdminLoginValidation}/>
            <Route exact path="/student/:studentId" component={Student}/>
            <Route exact path="/student/applyCompany/:studentId" component={ApplyForCompany}/>
            <Route exact path="/student/showAppliedCompanies/:studentId" component={ShowAppliedCompanies}/>
            <Route exact path="/student/marks/:studentId" component={StudentMarks}/>
            <Route exact path="/adminLoggedIn" component={FirstPage}/>
            <Route exact path="/update/:studentId" component={StudentComponent}/>
            <Route exact path="/goToCompany" component={ListCompanyComponent}/>
            <Route exact path="/addCompany" component={CompanyComponent}/>
            <Route exact path="/addMarks" component={AddMarks}/>
            <Route exact path="/addStudent" component={AddStudent}/>
            <Route exact path="/displayStudent" component={ListStudentComponent}/>
            </Switch>
        </Router>   
        
 <Footer/> 
       
      </div>
    );
  }
}

export default App;