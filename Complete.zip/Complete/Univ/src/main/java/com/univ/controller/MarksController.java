package com.univ.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.univ.model.Marks;
import com.univ.service.MarksService;

@RestController
@RequestMapping("marks")
@CrossOrigin(origins= {"http://localhost:3000"})
public class MarksController {
	@Autowired
	MarksService marksService;
	@PostMapping("/studentId/{studentId}")
	public ResponseEntity<Marks> addMarks(@PathVariable("studentId")int studentId,@RequestBody Marks marks){
		if(marksService.isMarksDataExists(studentId)) {
			return new ResponseEntity<Marks>(HttpStatus.ACCEPTED);
		}
		else {
		marksService.addMarks(studentId, marks);
		return new ResponseEntity<Marks>(HttpStatus.OK);
		}
	}
	@GetMapping("/studentId/{studentId}")
	public ResponseEntity<List<Marks>> getMarksOfAStudent(@PathVariable("studentId")int studentId){
		if(marksService.isMarksDataExists(studentId)) {
			List<Marks> marksOfAStudent = marksService.getMarksOfAStudent(studentId);
			return new ResponseEntity<List<Marks>>(marksOfAStudent,HttpStatus.OK);
		}
		else
			return new ResponseEntity<List<Marks>>(HttpStatus.NO_CONTENT);
	}

	@PutMapping("/studentId/{studentId}")
	public ResponseEntity<Marks> updateMarks(@PathVariable("studentId")int studentId,@RequestBody Marks marks){
		if(marksService.isMarksDataExists(studentId)) {
			marksService.updateMarks(studentId, marks);
			return new ResponseEntity<Marks>(HttpStatus.OK);
		}
		else
			return new ResponseEntity<Marks>(HttpStatus.ACCEPTED);
	}
}
