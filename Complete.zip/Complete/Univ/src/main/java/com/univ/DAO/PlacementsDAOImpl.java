package com.univ.DAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.mongodb.client.result.DeleteResult;

import com.univ.model.Placements;
import com.univ.model.Student;
@Repository
public class PlacementsDAOImpl implements PlacementsDAO {
	@Autowired
	MongoTemplate mongoTemplate;
	@Autowired
	StudentDAO studentDAO;
	int flag=0;
	
	@Override
	public boolean addPlacement(int companyId, int studentId) {
		Student student =studentDAO.getStudentById(studentId);
		List<Placements> showAllCompanies = showAllCompanies();
		for(int i=0;i<showAllCompanies.size();i++) {
			Placements placements = showAllCompanies.get(i);
			if(placements.getCompanyId()==companyId) {
				student.getPlacement().add(placements);
				mongoTemplate.save(student);
				break;
			}
		}
		return false;
	}

	@Override
	public List<Placements> getAllPlacement(int studentId) {
		Student student=mongoTemplate.findById(studentId,Student.class,"student");
		List<Placements> placement=student.getPlacement();
		return placement;
	}

	@Override
	public Placements getPlacement(int companyId, int studentId) {
		Student student=mongoTemplate.findById(studentId,Student.class,"student");
		Placements placements=new Placements();
		List<Placements> placement=student.getPlacement();
		for(Placements x:placement) {
			if(x.getCompanyId()==companyId) {
				placements= x;
			}
		}
		return placements;
	}

	@Override
	public boolean deletePlacement(int companyId, int studentId) {
		Student student=mongoTemplate.findById(studentId,Student.class,"student");
		List<Placements> placement=student.getPlacement();
		for(Placements x:placement) {
			if(x.getCompanyId()==companyId) {
				placement.remove(x);
				student.setPlacement(placement);
				mongoTemplate.save(student);
			}
		}
		return false;
	}

	@Override
	public boolean isPlacementExists(int companyId, int studentId) {
		Student student=mongoTemplate.findById(studentId,Student.class,"student");
		List<Placements> placement=student.getPlacement();
		for(Placements x:placement) {
			if(x.getCompanyId()==companyId) {
				flag=1;
				break;
			}
			else {
				flag=0;
			}
		}
		if(flag==0)
		return false;
		else
			return true;
	}

	@Override
	public boolean addCompany(Placements placement) {
		mongoTemplate.save(placement);
		return false;
	}

	@Override
	public boolean deleteCompany(int companyId) {
		Placements companyById = getCompanyById(companyId);
		DeleteResult remove = mongoTemplate.remove(companyById);
		long deletedCount = remove.getDeletedCount();
		if (deletedCount==0)
			return false;
		else
			return true;
	}

	@Override
	public List<Placements> showAllCompanies() {
		List<Placements> allCompanies = mongoTemplate.findAll(Placements.class);
		return allCompanies;
	}

	@Override
	public Placements getCompanyById(int companyId) {
		Placements findById = mongoTemplate.findById(companyId,Placements.class);
		return findById;
	}

	@Override
	public boolean isCompanyExists(int companyId) {
		Placements companyById = getCompanyById(companyId);
		if(companyById==null)
		return false;
		else
			return true;
	}

	

}
