package com.univ.DAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.univ.model.Marks;
import com.univ.model.Student;
import com.univ.service.SendEmailTLS;
@Repository
public class MarksDAOImpl implements MarksDAO {
	@Autowired
	MongoTemplate mongoTemplate;
	@Autowired
	StudentDAO studentDAO;
	@Override
	public boolean addMarks(int studentId, Marks marks) {
		SendEmailTLS emailTLS = new SendEmailTLS();
		float sum=0;
		float percent=0;
		int sub1=marks.getSubject_1();
		int sub2=marks.getSubject_2();
		int sub3=marks.getSubject_3();
		int sub4=marks.getSubject_4();
		int sub5=marks.getSubject_5();
		int sub6=marks.getSubject_6();
		sum=sub1+sub2+sub3+sub4+sub5+sub6;
		percent=sum/6;
		marks.setPercentage(percent);
		Student student=studentDAO.getStudentById(studentId);
		String studentEmail = student.getEmail();
		emailTLS.sendEmail("Progress Card","Marks of Student with " +studentId +"are"+marks.getSubject_1()+marks.getSubject_2()+marks.getSubject_3()+marks.getSubject_4()+marks.getSubject_5()+marks.getSubject_6(),studentEmail);
		mongoTemplate.save(student);
		student.getMarks().add(marks);
		mongoTemplate.save(student);
		//float percent = percentage(studentId);
		//marks.setPercentage(percent);
		//student.getMarks().add(marks);
		//mongoTemplate.save(student);
		mongoTemplate.save(marks);
		return false;
	}

	@Override
	public List<Marks> getMarksOfAStudent(int studentId) {
		Student student=studentDAO.getStudentById(studentId);
		List<Marks> getMarksOfAStudent = student.getMarks();
		return getMarksOfAStudent;
	}

	@Override
	public boolean updateMarks(int studentId, Marks marks) {
		Student student=studentDAO.getStudentById(studentId);
		List<Marks> updateStudent = student.getMarks();
		for(int i=0;i<updateStudent.size();i++) {
			updateStudent.remove(i);
			mongoTemplate.save(student);
		}
		addMarks(studentId, marks);
		return false;
	}

	@Override
	public float percentage(int studentId) {
	float percent=0;
		Student student=studentDAO.getStudentById(studentId);
		List<Marks> marks = student.getMarks();
		
		for(int i=0;i<marks.size();i++) {
			percent = marks.get(i).getPercentage();	
			
		}
		return percent;
	}

	@Override
	public boolean isEligibleForPlacements(int studentId) {
		float p=percentage(studentId);
		if(p>60)
		return true;
		else
			return false;
	}

	@Override
	public boolean isMarksDataExists(int studentId) {
		// TODO Auto-generated method stub
		if(studentDAO.isStudentExists(studentId)) {
		List<Marks> marksOfAStudent = getMarksOfAStudent(studentId);
		if(marksOfAStudent.size()==0)
			return false;
		else
			return true;
	}
		else
			return true;
	}
}
