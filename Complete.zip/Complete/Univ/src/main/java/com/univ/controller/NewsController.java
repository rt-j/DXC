package com.univ.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.univ.model.News;
import com.univ.service.NewsService;

@RestController
@RequestMapping("news")
@CrossOrigin(origins = { "http://localhost:3000", "http://localhost:4200" })
public class NewsController {

	@Autowired
	NewsService newsService;

	// getting single news

	@GetMapping("/{newsId}")
	public ResponseEntity<News> getNews(@PathVariable("newsId") int newsId) {
		News news = new News();
		if (newsService.isNewsExists(newsId)) {
			news = newsService.displayNews(newsId);
			return new ResponseEntity<News>(news, HttpStatus.OK);
		} else {
			return new ResponseEntity<News>(news, HttpStatus.NO_CONTENT);
		}
	}

	// delete single news

	@DeleteMapping("/{newsId}")
	public ResponseEntity<News> deleteNews(@PathVariable("newsId") int newsId) {
		if (newsService.isNewsExists(newsId)) {
			newsService.deleteNews(newsId);
			return new ResponseEntity<News>(HttpStatus.NO_CONTENT);
		} else {
			return new ResponseEntity<News>(HttpStatus.NOT_FOUND);
		}
	}

	// to save one news

	@PostMapping()
	public ResponseEntity<News> saveNews(@RequestBody News news) {
		System.out.println(news);
		if (newsService.isNewsExists(news.getNewsId())) {
			return new ResponseEntity<News>(HttpStatus.CONFLICT);
		} else {
			newsService.addNews(news);
			return new ResponseEntity<News>(HttpStatus.CREATED);
		}
	}

}
