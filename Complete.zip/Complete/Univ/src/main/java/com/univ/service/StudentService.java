package com.univ.service;

import java.util.List;

import com.univ.model.Student;

public interface StudentService {
	public Student getStudentById(int studentId);
	public boolean addStudent(Student student);
	public boolean updateStudent(Student student);
	public boolean deleteStudent(int studentId);
	public List<Student> getAllStudentDetails();
	public boolean isStudentExists(int studentId);
	public boolean checkLogin(int studentId,String name,String password);
	public boolean forgotPassword(int studentId);

}
