package com.univ.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.OneToMany;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document
public class Student {
	@Id
	private int studentId;
	private String studentName;
	private String course;
	private String password;
	private String email;
	@OneToMany(cascade = CascadeType.PERSIST)
	private List<Marks> marks= new ArrayList<Marks>();
	@OneToMany(cascade = CascadeType.DETACH)
	private List<Placements> placement= new ArrayList<Placements>();
	
	public Student() {
		// TODO Auto-generated constructor stub
	}

	public Student(int studentId, String studentName, String course, String password, String email, List<Marks> marks,
			List<Placements> placement) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.course = course;
		this.password = password;
		this.email = email;
		this.marks = marks;
		this.placement = placement;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<Marks> getMarks() {
		return marks;
	}

	public void setMarks(List<Marks> marks) {
		this.marks = marks;
	}

	public List<Placements> getPlacement() {
		return placement;
	}

	public void setPlacement(List<Placements> placement) {
		this.placement = placement;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", course=" + course + ", password="
				+ password + ", email=" + email + ", marks=" + marks + ", placement=" + placement + "]";
	}

	
	



	
}
