package com.univ.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.univ.DAO.StudentDAO;
import com.univ.model.Student;
@Service
public class StudentServiceImpl implements StudentService {
	@Autowired
	StudentDAO studentDAO;

	@Override
	public Student getStudentById(int studentId) {
		// TODO Auto-generated method stub
		 return studentDAO.getStudentById(studentId);
	}

	@Override
	public boolean addStudent(Student student) {
		// TODO Auto-generated method stub
		return studentDAO.addStudent(student);
	}

	@Override
	public boolean updateStudent(Student student) {
		// TODO Auto-generated method stub
		return studentDAO.updateStudent(student);
	}

	@Override
	public boolean deleteStudent(int studentId) {
		// TODO Auto-generated method stub
		return studentDAO.deleteStudent(studentId);
	}

	@Override
	public List<Student> getAllStudentDetails() {
		// TODO Auto-generated method stub
		return studentDAO.getAllStudentDetails();
	}

	@Override
	public boolean isStudentExists(int studentId) {
		// TODO Auto-generated method stub
		return studentDAO.isStudentExists(studentId);
	}

	@Override
	public boolean checkLogin(int studentId, String name, String password) {
		// TODO Auto-generated method stub
		return studentDAO.checkLogin(studentId, name, password);
	}

	@Override
	public boolean forgotPassword(int studentId) {
		return studentDAO.forgotPassword(studentId);
	}
	
	
}
