package com.univ.DAO;

import java.util.List;

import com.univ.model.Marks;

public interface MarksDAO {
	public boolean addMarks(int studentId,Marks marks);
	public List<Marks> getMarksOfAStudent(int studentId);
	public boolean updateMarks(int studentId,Marks marks);
	public float percentage(int studentId);
	public boolean isEligibleForPlacements(int studentId);
	public boolean isMarksDataExists(int studentId);
}
