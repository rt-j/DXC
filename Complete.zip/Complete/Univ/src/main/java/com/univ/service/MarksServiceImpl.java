package com.univ.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.univ.DAO.MarksDAO;
import com.univ.model.Marks;
@Service
public class MarksServiceImpl implements MarksService {
	@Autowired
	MarksDAO marksDAO;
	@Override
	public boolean addMarks(int studentId, Marks marks) {
		// TODO Auto-generated method stub
		return marksDAO.addMarks(studentId, marks);
	}

	@Override
	public List<Marks> getMarksOfAStudent(int studentId) {
		// TODO Auto-generated method stub
		return marksDAO.getMarksOfAStudent(studentId);
	}

	@Override
	public boolean updateMarks(int studentId, Marks marks) {
		// TODO Auto-generated method stub
		return marksDAO.updateMarks(studentId, marks);
	}

	@Override
	public float percentage(int studentId) {
		// TODO Auto-generated method stub
		return marksDAO.percentage(studentId);
	}

	@Override
	public boolean isEligibleForPlacements(int studentId) {
		// TODO Auto-generated method stub
		return marksDAO.isEligibleForPlacements(studentId);
	}

	@Override
	public boolean isMarksDataExists(int studentId) {
		// TODO Auto-generated method stub
		return marksDAO.isMarksDataExists(studentId);
	}

}
