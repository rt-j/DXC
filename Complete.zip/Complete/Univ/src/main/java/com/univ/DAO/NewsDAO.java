package com.univ.DAO;

import com.univ.model.News;

public interface NewsDAO {

	public boolean addNews(News news);

	public boolean deleteNews(int newsId);

	public News displayNews(int newsId);

	public boolean isNewsExists(int newsId);
}
