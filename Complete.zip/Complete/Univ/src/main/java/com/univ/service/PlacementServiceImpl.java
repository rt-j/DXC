package com.univ.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.univ.DAO.PlacementsDAO;
import com.univ.model.Placements;
@Service
public class PlacementServiceImpl implements PlacementService {
	@Autowired
	PlacementsDAO placementDAO;
	@Override
	public boolean addPlacement(int companyId, int studentId) {
		// TODO Auto-generated method stub
		return placementDAO.addPlacement(companyId, studentId);
	}

	@Override
	public List<Placements> getAllPlacement(int studentId) {
		// TODO Auto-generated method stub
		return placementDAO.getAllPlacement(studentId);
	}

	@Override
	public Placements getPlacement(int companyId, int studentId) {
		// TODO Auto-generated method stub
		return placementDAO.getPlacement(companyId, studentId);
	}

	@Override
	public boolean deletePlacement(int companyId, int studentId) {
		// TODO Auto-generated method stub
		return placementDAO.deletePlacement(companyId, studentId);
	}

	@Override
	public boolean isPlacementExists(int companyId, int studentId) {
		// TODO Auto-generated method stub
		return placementDAO.isPlacementExists(companyId, studentId);
	}

	@Override
	public boolean addCompany(Placements placement) {
		// TODO Auto-generated method stub
		return placementDAO.addCompany(placement);
	}

	@Override
	public boolean deleteCompany(int companyId) {
		// TODO Auto-generated method stub
		return placementDAO.deleteCompany(companyId);
	}

	@Override
	public List<Placements> showAllCompanies() {
		// TODO Auto-generated method stub
		return placementDAO.showAllCompanies();
	}

	@Override
	public Placements getCompanyById(int companyId) {
		// TODO Auto-generated method stub
		return placementDAO.getCompanyById(companyId);
	}

	@Override
	public boolean isCompanyExists(int companyId) {
		// TODO Auto-generated method stub
		return placementDAO.isCompanyExists(companyId);
	}

}
