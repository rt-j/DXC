package com.univ.model;


import org.springframework.data.mongodb.core.mapping.Document;
@Document
public class Marks {
	private int subject_1;
	private int subject_2;
	private int subject_3;
	private int subject_4;
	private int subject_5;
	private int subject_6;
	private float percentage;
	
	public Marks() {
		// TODO Auto-generated constructor stub
	}

	public Marks( int subject_1, int subject_2, int subject_3, int subject_4, int subject_5, int subject_6,
			float percentage) {
		super();
		
		this.subject_1 = subject_1;
		this.subject_2 = subject_2;
		this.subject_3 = subject_3;
		this.subject_4 = subject_4;
		this.subject_5 = subject_5;
		this.subject_6 = subject_6;
		this.percentage = percentage;
	}

	
	public int getSubject_1() {
		return subject_1;
	}

	public void setSubject_1(int subject_1) {
		this.subject_1 = subject_1;
	}

	public int getSubject_2() {
		return subject_2;
	}

	public void setSubject_2(int subject_2) {
		this.subject_2 = subject_2;
	}

	public int getSubject_3() {
		return subject_3;
	}

	public void setSubject_3(int subject_3) {
		this.subject_3 = subject_3;
	}

	public int getSubject_4() {
		return subject_4;
	}

	public void setSubject_4(int subject_4) {
		this.subject_4 = subject_4;
	}

	public int getSubject_5() {
		return subject_5;
	}

	public void setSubject_5(int subject_5) {
		this.subject_5 = subject_5;
	}

	public int getSubject_6() {
		return subject_6;
	}

	public void setSubject_6(int subject_6) {
		this.subject_6 = subject_6;
	}

	public float getPercentage() {
		return percentage;
	}

	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}


	@Override
	public String toString() {
		return "Marks [subject_1=" + subject_1 + ", subject_2=" + subject_2 + ", subject_3="
				+ subject_3 + ", subject_4=" + subject_4 + ", subject_5=" + subject_5 + ", subject_6=" + subject_6
				+ ", percentage=" + percentage + "]";
	}
	
	
}
