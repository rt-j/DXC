package com.univ.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.univ.model.Student;
import com.univ.service.StudentService;

@RestController
@RequestMapping("student")
@CrossOrigin(origins= {"http://localhost:3000"})
public class StudentController {
	@Autowired
	StudentService studentService;
	@GetMapping("/{studentId}")
	public  ResponseEntity<Student> getStudentById(@PathVariable("studentId")int studentId){
		if(studentService.isStudentExists(studentId)) {
			Student studentById = studentService.getStudentById(studentId);
			return new ResponseEntity<Student>(studentById,HttpStatus.OK);
		}
		else
			return new ResponseEntity<Student>(HttpStatus.NO_CONTENT);
	}
	@PostMapping()
	public ResponseEntity<Student> addStudent(@RequestBody Student student){
		System.out.println("abv");
		if(studentService.isStudentExists(student.getStudentId())) {
			return new ResponseEntity<Student>(HttpStatus.ACCEPTED);
		}
		else
		{
			studentService.addStudent(student);
			System.out.println("Sent");
			return new ResponseEntity<Student>(HttpStatus.OK);
		}

	}
	@PutMapping()
	public ResponseEntity<Student> updateStudent(@RequestBody Student student){
		if(studentService.isStudentExists(student.getStudentId())) {
			studentService.updateStudent(student);
			return new ResponseEntity<Student>(HttpStatus.ACCEPTED);
		}
		else
			return new ResponseEntity<Student>(HttpStatus.OK);
	}
	@DeleteMapping("/{studentId}")
	public  ResponseEntity<Student> deleteStudent(@PathVariable("studentId")int studentId){
		if(studentService.isStudentExists(studentId)){
			studentService.deleteStudent(studentId);
			return new ResponseEntity<Student>(HttpStatus.OK);
		}
		else
			return new ResponseEntity<Student>(HttpStatus.NO_CONTENT);

	}
	@GetMapping()
	public ResponseEntity<List<Student>>getAllStudentDetails(){
	List<Student> allStudentDetails = studentService.getAllStudentDetails();
	return new ResponseEntity<List<Student>>(allStudentDetails,HttpStatus.OK);
	}
	
	@GetMapping("/check/{studentId}/{name}/{password}")
	public ResponseEntity<Student> checkLogin(@PathVariable("studentId")int studentId,@PathVariable("name")String studentName,@PathVariable("password")String password){
		if(studentService.checkLogin(studentId, studentName, password)) {
			return new ResponseEntity<Student>(HttpStatus.OK);
		}
		else
			return new ResponseEntity<Student>(HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/sendPassword/studentId/{studentId}")
	public ResponseEntity<Student> forgotPassword(@PathVariable("studentId")int sId){
		
		if(studentService.forgotPassword(sId)) {
		return new ResponseEntity<Student>(HttpStatus.OK);
	}
		else {
			return new ResponseEntity<Student>(HttpStatus.ACCEPTED);
		}
	}


}
