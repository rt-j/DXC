package com.univ.service;

import com.univ.model.News;

public interface NewsService {

	public boolean addNews(News news);

	public boolean deleteNews(int newsId);

	public News displayNews(int newsId);

	public boolean isNewsExists(int newsId);
}
