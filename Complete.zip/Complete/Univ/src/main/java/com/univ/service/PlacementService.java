package com.univ.service;

import java.util.List;

import com.univ.model.Placements;

public interface PlacementService {
	public boolean addPlacement(int companyId,int studentId);
	public List<Placements>getAllPlacement(int studentId);
	public Placements getPlacement(int companyId,int studentId);
	public boolean deletePlacement(int companyId,int studentId);
	public boolean isPlacementExists(int companyId,int studentId);
	public boolean addCompany(Placements placement);
	public boolean deleteCompany(int companyId);
	public List<Placements> showAllCompanies();
	public Placements getCompanyById(int companyId);
	public boolean isCompanyExists(int companyId);
}
