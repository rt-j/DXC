package com.univ.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.univ.DAO.StudentDAO;
import com.univ.model.Marks;

public class MarksControllerTest extends AbstractTest {

	@Autowired
	StudentDAO studentDAO;

	@Override
	@Before
	public void setUp() {
		super.setUp();
	}
	@Test
	public void testAddMarks() throws Exception {
		String uri = "/marks/studentId/1";
		Marks marks = new Marks();
		marks.setSubject_1(1);
		marks.setSubject_2(1);
		marks.setSubject_3(1);
		marks.setSubject_4(1);
		marks.setSubject_5(1);
		marks.setSubject_6(1);
		String inputJson = super.mapToJson(marks);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(409, status);
	}

	@Test
	public void testGetMarksOfAStudent() throws Exception {
		String uri = "/marks/studentId/5";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);

		String content = mvcResult.getResponse().getContentAsString();
		Marks[] marks = super.mapFromJson(content, Marks[].class);
		assertTrue(marks.length > 0);
	}

	@Test
	public void testUpdateMarks() throws Exception {
		String uri = "/marks/studentId/5";
		Marks marks = new Marks();
		marks.setSubject_1(2);
		marks.setSubject_2(2);
		marks.setSubject_3(2);
		marks.setSubject_4(2);
		marks.setSubject_5(2);
		marks.setSubject_6(2);
		String inputJson = super.mapToJson(marks);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.put(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

}
