package com.univ.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.univ.model.Student;

public class StudentServiceControllerTest extends AbstractTest {
	@Override
	@Before
	public void setUp() {
		super.setUp();
	}

	@Test
	public void testGetAllStudentDetails() throws Exception {
		
		String uri = "/student";

		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);

		String content = mvcResult.getResponse().getContentAsString();
		Student[] studentlist = super.mapFromJson(content, Student[].class);
		assertTrue(studentlist.length > 0);
	}

	@Test
	public void testGetStudentById() throws Exception {

		// localhost:8001/student -GET
		String uri = "/student/5";

		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);

		String content = mvcResult.getResponse().getContentAsString();
		Student studentlist = super.mapFromJson(content, Student.class);
		assertNotNull(studentlist);
	}

	// testing for conflict
	@Test
	public void testAddStudent() throws Exception {
		String uri = "/student";
		Student student = new Student();
		student.setStudentId(5);
		student.setStudentName("Bag");
		student.setCourse("11");
		student.setPassword("11");
		String inputJson = super.mapToJson(student);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(409, status);
	}

	@Test
	public void testUpdateStudent() throws Exception {
		String uri = "/student";
		Student student = new Student();
		student.setStudentId(5);
		student.setStudentName("Bagadcv");
		student.setCourse("11");
		student.setPassword("11");
		String inputJson = super.mapToJson(student);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.put(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(202, status);
	}

	@Test
	public void testDeleteStudent() throws Exception {
		String uri = "/student/2";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.delete(uri)).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}
}