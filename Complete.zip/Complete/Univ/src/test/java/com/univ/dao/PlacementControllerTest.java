package com.univ.dao;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.univ.model.Placements;

public class PlacementControllerTest extends AbstractTest {

	@Override
	@Before
	public void setUp() {
		super.setUp();
	}

	@Test
	public void testAddPlacement() throws Exception {
		String uri = "/placement";
		Placements placements = new Placements();
		placements.setCompanyId(1);
		placements.setCompanyName("A");
		placements.setCompensation("A");
		placements.setEligibility("A");
		String inputJson = super.mapToJson(placements);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(409, status);
	}

	@Test
	public void testGetAllPlacement() throws Exception {
		String uri = "/placement";

		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);

		String content = mvcResult.getResponse().getContentAsString();
		Placements[] placementlist = super.mapFromJson(content, Placements[].class);
		assertTrue(placementlist.length > 0);
	}

	@Test
	public void testGetPlacement() throws Exception {
		String uri = "/placement/companyId/1";

		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);

		String content = mvcResult.getResponse().getContentAsString();
		Placements placementlist = super.mapFromJson(content, Placements.class);
		assertNotNull(placementlist);
	}

	@Test
	public void testDeletePlacement() throws Exception {
		String uri = "/placement/companyId/1";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.delete(uri)).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	public void testAddCompany() throws Exception {
		String uri = "/placement";
		Placements placements = new Placements();
		placements.setCompanyId(2);
		placements.setCompanyName("A");
		placements.setCompensation("A");
		placements.setEligibility("A");
		String inputJson = super.mapToJson(placements);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(409, status);
	}

	@Test
	public void testDeleteCompany() throws Exception {
		String uri = "/placement/companyId/2";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.delete(uri)).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	public void testShowAllCompanies() throws Exception {
		String uri = "/placement";

		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);

		String content = mvcResult.getResponse().getContentAsString();
		Placements[] placementlist = super.mapFromJson(content, Placements[].class);
		assertTrue(placementlist.length > 0);
	}

	@Test
	public void testGetCompanyById() throws Exception {
		String uri = "/placement/companyId/1";

		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();

		assertEquals(200, status);

		String content = mvcResult.getResponse().getContentAsString();
		Placements placementlist = super.mapFromJson(content, Placements.class);
		assertNotNull(placementlist);
	}

}
