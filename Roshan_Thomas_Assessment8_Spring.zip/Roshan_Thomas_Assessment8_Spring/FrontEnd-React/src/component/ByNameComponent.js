import React, { Component } from 'react'
import ProductDataService from '../service/ProductDataService'

class ListProductComponent extends Component {
    constructor(props) {
        super(props)
        

        this.state = {
                pname:this.props.match.params.pName,
                 products:[]
                
        }
    }
    componentWillMount(){
       this.refresh();
    }
    refresh(){
        ProductDataService.getProductByName(this.state.pname).then(
            response=>{
                this.setState({
                    products:response.data,
                    
                })
                console.log(response.data);
            }
        )
    }
   

    render() {
        return (
            <div>
                {this.state.message&&<div className="alert alert-success">{this.state.message}</div>}
                <h1>MY Product</h1>
                <div className="container">
                    <table className="table">
                        <thead>
                            <tr>
                                <td>ProductId</td>
                                <td>ProductName</td>
                                <td>Quantity</td>
                                <td>Price</td> 
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.products.map(product=>
                                    <tr key={product.productId}>
                                        <td>{product.productId}</td>
                                        <td>{product.productName}</td>
                                        <td>{product.quantityOnHand}</td>
                                        <td>{product.price}</td> 
                                    </tr>
                                 )
                                    
                            }
                        </tbody>
                    </table>
                   
                </div>
                
            </div>
        )
    }
}

export default ListProductComponent
