import React, { Component } from 'react'
import ProductDataService from '../service/ProductDataService'
import { Formik, Form, Field, ErrorMessage } from 'formik'

class ProductComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
                 productId:this.props.match.params.pId,
                 productName:'',
                 quantityOnHand:'',
                 price:''
        }
        this.onSubmit=this.onSubmit.bind(this);
    }
    componentWillMount(){
       // if(this.state.productId==-1)
       // return
        ProductDataService.getProduct(this.state.productId).then(
            response=>{
                this.setState({
                    productName:response.data.productName,
                    quantityOnHand:response.data.quantityOnHand,
                    price:response.data.price
                })
            }
        )
    }
    onSubmit(product){
        if(this.state.productId==-1){
        ProductDataService.addProduct(product).then(()=>this.props.history.push(`/`))
    }
        
    else if(this.state.productId==0){
       this.props.history.push(`/name/${product.productName}`)
    }
    else{
        ProductDataService.updateProduct(product).then(()=>this.props.history.push(`/afterupdate`))
    }
     }
    
    validateMyForm(value){
        let errors={}
        if(!value.productName){
            errors.productName='Enter a Name'
        }
         if(value.productName.length<5){
            errors.productName='Enter more than 5 characters'
        }
        
    
        return errors
    }

    render() {
        let{productId,productName,quantityOnHand,price}=this.state
        
    
        return (
            <div>
               <h1>Add and Update Product {this.state.productId}</h1> 
              {/*  <h1>Product Name:{this.state.productName}</h1>
               <h1>{this.state.quantityOnHand}</h1>
               <h1>{this.state.price}</h1> */}
               
               <Formik
                   initialValues={{productId,productName,quantityOnHand,price}} enableReinitialize={true}
                   onSubmit={this.onSubmit}
                    validateOnChange={false}
                    validateOnBlur={false}
                    validate={this.validateMyForm}
                   >
                   
                   <Form align="center">
                       <ErrorMessage name="productId" component="div" className="alert alert-danger"/>
                       <ErrorMessage name="productName" component="div" className="alert alert-danger"/>
                       <ErrorMessage name="quantityOnHand" component="div" className="alert alert-danger"/>
                       <ErrorMessage name="price" component="div" className="alert alert-danger"/>
                       <fieldset className="form-group">
                           <label>ProductId</label>
                           
                           <Field className="form-control" type="text" name="productId" disabled={(this.state.productId!=-1)?true:false} ></Field>
                       </fieldset>
                       <fieldset className="form-group">
                           <label>ProductName</label>
                           <Field className="form-control" type="text" name="productName"></Field>
                       </fieldset>
                       <fieldset className="form-group">
                           <label>QuantityOnHand</label>
                           <Field className="form-control" type="text" name="quantityOnHand" disabled={(this.state.productId==0)?true:false}></Field>
                       </fieldset>
                       <fieldset className="form-group">
                           <label>Price</label>
                           <Field className="form-control" type="text" name="price" disabled={(this.state.productId==0)?true:false}></Field>
                       </fieldset>
                       <button className="btn btn-success" type="submit">Update or SearchByName</button>
                   </Form>
               </Formik>
    }
            </div>
        )
    }
}

export default ProductComponent
