import React, { Component } from 'react'
import ListProductComponent from './component/ListProductComponent'
import './App.css'
import {Switch,Route} from 'react-router-dom';
import {BrowserRouter as Router} from 'react-router-dom';
import ProductComponent from './component/ProductComponent';
import ByNameComponent from './component/ByNameComponent';
class App extends Component {
  constructor(props) {
    super(props)

    this.state = {
         
    }
  }

  render() {
    return (
      <div>
        <Router>
        <Switch>
       <Route exact path="/" component={ListProductComponent}></Route>
       <Route exact path="/product/:pId" component={ProductComponent}/>
       <Route exact path="/name/:pName" component={ByNameComponent}/>
       <Route exact path="/afterupdate" component={ListProductComponent}/>
     
       </Switch>
       </Router>
      </div>
    )
  }
}

export default App
