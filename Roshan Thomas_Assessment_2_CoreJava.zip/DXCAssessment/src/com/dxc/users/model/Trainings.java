package com.dxc.users.model;

public class Trainings {
private int sap_Id;
private String empName;
private String stream;
private int percentage;
public Trainings(int sap_Id, String empName, String stream, int percentage) {
	super();
	this.sap_Id = sap_Id;
	this.empName = empName;
	this.stream = stream;
	this.percentage = percentage;
}


public Trainings() {
	super();
}


public int getSap_Id() {
	return sap_Id;
}

public void setSap_Id(int sap_Id) {
	this.sap_Id = sap_Id;
}

public String getEmpName() {
	return empName;
}

public void setEmpName(String empName) {
	this.empName = empName;
}

public String getStream() {
	return stream;
}

public void setStream(String stream) {
	this.stream = stream;
}

public int getPercentage() {
	return percentage;
}

public void setPercentage(int percentage) {
	this.percentage = percentage;
}

@Override
public String toString() {
	return "Trainings [sap_Id=" + sap_Id + ", empName=" + empName + ", stream=" + stream + ", percentage=" + percentage
			+ "]";
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((empName == null) ? 0 : empName.hashCode());
	result = prime * result + percentage;
	result = prime * result + sap_Id;
	result = prime * result + ((stream == null) ? 0 : stream.hashCode());
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Trainings other = (Trainings) obj;
	if (empName == null) {
		if (other.empName != null)
			return false;
	} else if (!empName.equals(other.empName))
		return false;
	if (percentage != other.percentage)
		return false;
	if (sap_Id != other.sap_Id)
		return false;
	if (stream == null) {
		if (other.stream != null)
			return false;
	} else if (!stream.equals(other.stream))
		return false;
	return true;
}

}
