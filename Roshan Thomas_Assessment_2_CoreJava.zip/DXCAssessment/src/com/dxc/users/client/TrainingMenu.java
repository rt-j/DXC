package com.dxc.users.client;
import com.dxc.users.DAO.TrainingsDAO;
import com.dxc.users.DAO.TrainingsDAOImpl;


import java.util.Scanner;

public class TrainingMenu {
	Scanner scanner=new Scanner(System.in);
	int choice;
	TrainingsDAO trainingDAO=new TrainingsDAOImpl() ;
	public TrainingMenu() {
		// TODO Auto-generated constructor stub
	}
	public void launchMenu() {
		while(true) {
			System.out.println("Menu");
			System.out.println("1.Display All Records");
			System.out.println("2.Display Records one by one and Update Percentage");
			System.out.println("3.Exit");
			System.out.println("Enter the choice");
			choice=scanner.nextInt();
			switch(choice) {
			case 1:
				System.out.println(trainingDAO.displayRecords());
				break;
			case 2:
				trainingDAO.addPercent();
				break;
			case 3:
				System.exit(0);
				break;
			}
		}
	}
}
