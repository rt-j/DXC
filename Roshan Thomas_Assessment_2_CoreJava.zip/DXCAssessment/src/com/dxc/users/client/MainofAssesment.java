package com.dxc.users.client;

import com.dxc.users.DAO.TrainingsDAOImpl;
import com.dxc.users.DAO.UserDAOImpl;

public class MainofAssesment {
	
public static void main(String[] args) {
	boolean s;
	
	UserDAOImpl u=new UserDAOImpl();
	s=u.validate();
	//if only it is validated
	if(s) {
	TrainingMenu trainingObject=new TrainingMenu();
	trainingObject.launchMenu();
	}
	
	
}
}
