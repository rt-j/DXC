package com.dxc.users.DAO;

public interface UserDAO {
public boolean validate();
public boolean confirm(String s,String m);
}
