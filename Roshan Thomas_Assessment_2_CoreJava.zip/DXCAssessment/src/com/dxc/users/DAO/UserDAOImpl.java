package com.dxc.users.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import com.dxc.users.connectdb.*;

public class UserDAOImpl implements UserDAO {
	private String username;
	private String password;
	Scanner sc = new Scanner(System.in);

	Connection connection = CommonDB.getConnection();
	private static final String CHECK_USERNAME = "select * from users where userName=? and password1=?";

	@Override
	public boolean validate() {
		boolean t=false;
		System.out.println("Enter your credentials");

		username = sc.next();
		System.out.println("Password:");
		password = sc.next();

		if (confirm(username, password)) {
			System.out.println("correct username and password");
			t=true;
		} else {
			System.out.println("Wrong username and password");
			t=false;
		}
		return t;
	}

	@Override
	public boolean confirm(String username, String password) {
		boolean exits = false;
		try {

			PreparedStatement ps = connection.prepareStatement(CHECK_USERNAME);
			ps.setString(1, username);
			ps.setString(2, password);
			ResultSet r = ps.executeQuery();
			if (r.next())
				exits = true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
		return exits;

	}
}
