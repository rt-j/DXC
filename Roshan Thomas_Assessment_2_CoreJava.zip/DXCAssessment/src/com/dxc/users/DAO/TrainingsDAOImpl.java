package com.dxc.users.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.dxc.users.connectdb.CommonDB;
import com.dxc.users.model.Trainings;
import com.mysql.jdbc.Statement;

public class TrainingsDAOImpl implements TrainingsDAO {
	private int percentage;
	private static final String DISPLAY_ALL = "select * from training";
	private static final String UPDATE_PERCENTAGE="Update training set percentage=? where sapId=?";
	Connection connection = CommonDB.getConnection();
	List<Trainings> allt=new ArrayList<Trainings>();
	Scanner sc=new Scanner(System.in);
	
				@Override
				public List<Trainings> displayRecords() {
					java.sql.Statement stat=null;
					try {
						stat=connection.createStatement();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						ResultSet res=null;
						 res=stat.executeQuery(DISPLAY_ALL);
						 while(res.next()) {
								Trainings training =new Trainings();
								training.setSap_Id(res.getInt(1));
								training.setEmpName(res.getString(2));
								training.setStream(res.getString(3));
						training.setPercentage(res.getInt(4));
								allt.add(training);
							}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					return  allt;
			
		}
		

	@Override
	public void addPercent() {
		try {
			Statement statement=(Statement) connection.createStatement();
			ResultSet resultSet=statement.executeQuery(DISPLAY_ALL);
			PreparedStatement preparedStatement;
			while(resultSet.next()) {
				System.out.println("SapId: "+resultSet.getString(1));
				System.out.println("Employee Name: "+resultSet.getString(2));
				System.out.println("Stream: "+resultSet.getString(3));
				if(resultSet.getInt(4)==0) {
					System.out.println("Enter The Percentage ");
					percentage=sc.nextInt();
					preparedStatement=connection.prepareStatement(UPDATE_PERCENTAGE);
					preparedStatement.setInt(1, percentage);
					preparedStatement.setString(2,resultSet.getString(1));
					preparedStatement.executeUpdate();
				}
				else {
					System.out.println("Percentage: "+resultSet.getInt(4));
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}

