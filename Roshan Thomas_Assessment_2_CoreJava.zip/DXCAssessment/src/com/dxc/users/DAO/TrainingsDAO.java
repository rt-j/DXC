package com.dxc.users.DAO;

import java.util.List;

import com.dxc.users.model.Trainings;

public interface TrainingsDAO {
public List<Trainings> displayRecords();
public void addPercent();

}
