package com.dxc.users.connectdb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CommonDB {
	public static Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("DriverLoaded");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		Connection connection=null;
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/dxc","root","root");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("DB Connected");
		return connection;
	}
}
