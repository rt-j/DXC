package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerCloudClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerCloudClientApplication.class, args);
	}

}
