package com.dxc.movies.dao;

import java.util.List;

import com.dxc.movies.model.Movie;


import junit.framework.TestCase;

public class MovieDAOImplTest extends TestCase {
	MovieDAO m;
	@Override
	protected void setUp() throws Exception {
		// TODO Auto-generated method stub
		super.setUp();
		m=new MovieDAOImpl();
	}

	
	  public void testGetMovie() { 
		  //fail("Not yet implemented"); 
		  Movie movie=new Movie(3, "D3", "Hyd", 200); 
		  m.addMovie(movie); 
		  Movie got=m.getMovie(3);
	  assertEquals(movie, got); 
	  }
	  
	  public void testGetAllMovie() { 
		  //fail("Not yet implemented"); 
		 List<Movie> BeforeAdding=m.getAllMovie();
		 Movie movie=new Movie(2, "Dim", "KL", 800);
	  m.addMovie(movie); 
	  List<Movie> AfterAdding=m.getAllMovie();
	  assertEquals(AfterAdding.size(), BeforeAdding.size()+1); }
	 
	public void testAddMovie() {
		//fail("Not yet implemented");
		Movie movie=new Movie(1, "Cid", "Bengaluru", 100);
		List<Movie> beforeAdd=m.getAllMovie();
		m.addMovie(movie);
		List<Movie> afterAdd=m.getAllMovie();
		assertEquals(afterAdd.size(), beforeAdd.size()+1);
		
		
	}

	
	  public void testDeleteMovie() { //fail("Not yet implemented"); 
		  List<Movie> BeforeDelete=m.getAllMovie(); 
		  m.deleteMovie(3); 
		  List<Movie>  AfterDelete=m.getAllMovie(); 
		  assertEquals(BeforeDelete.size()-1,AfterDelete.size());
		  }
	  
	  public void testUpdateMovie() { //fail("Not yet implemented"); 
		  Movie beforeUpdate=new Movie(5, "Z", "Punjab", 150); 
		  m.addMovie(beforeUpdate);
	  Movie afterUpdate=new Movie(5, "P", "Punjab", 150);
	  m.updateMovie(afterUpdate);
	  assertEquals(afterUpdate.getMovieName(), "P");
	  
	  }
	  
	  public void testIsMovieExists() { //fail("Not yet implemented");
		  Movie test=new Movie(7, "L", "America", 50);
		  m.addMovie(test); 
boolean check=m.isMovieExists(7); 
assertEquals(true, check);
}
	 

}
