package com.dxc.movies.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.movies.model.Movie;
import com.dxc.movies.util.HibernateUtil;


public class MovieDAOImpl implements MovieDAO {
	SessionFactory s=HibernateUtil.getSessionFactory();

	public Movie getMovie(int movieId) {
		// TODO Auto-generated method stub
		Session session=s.openSession();
		Movie movie=(Movie) session.get(Movie.class, movieId);
		return movie;
	}

	public List<Movie> getAllMovie() {
		// TODO Auto-generated method stub
		Session session=s.openSession();
		Query q=session.createQuery("from Movie");
		
		return q.list();
	}

	public void addMovie(Movie movie) {
		// TODO Auto-generated method stub
		Session session=s.openSession();
		Transaction t=session.beginTransaction();
		session.save(movie);
		t.commit();
		session.close();

	}

	public void deleteMovie(int movieId) {
		// TODO Auto-generated method stub
		Session session=s.openSession();
		Transaction transaction=session.beginTransaction();
		Movie movie=new Movie();
		movie.setMovieId(movieId);
		session.delete(movie);
		transaction.commit();
		session.close();

	}

	public void updateMovie(Movie movie) {
		// TODO Auto-generated method stub
		Session session=s.openSession();
		Transaction transaction =session.beginTransaction();
		session.update(movie);
		transaction.commit();
		session.close();

	}

	public boolean isMovieExists(int movieId) {
		// TODO Auto-generated method stub
		Session session=s.openSession();
Movie movie=(Movie) session.get(Movie.class, movieId);
if(movie==null)
		return false;
else
	return true;
	}

}
