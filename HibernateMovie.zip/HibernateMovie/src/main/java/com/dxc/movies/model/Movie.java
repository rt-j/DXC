package com.dxc.movies.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Movie {
	@Id
private int movieId;	
private String movieName;
private String location;
private int budget;

public Movie(int movieId,String movieName, String location, int budget) {
	super();
	this.movieId = movieId;
	this.movieName = movieName;
	this.location = location;
	this.budget = budget;
}

public Movie() {
	super();
}

public int getMovieId() {
	return movieId;
}
public void setMovieId(int movieId) {
	this.movieId = movieId;
}
public String getMovieName() {
	return movieName;
}
public void setMovieName(String movieName) {
	this.movieName = movieName;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public int getBudget() {
	return budget;
}
public void setBudget(int budget) {
	this.budget = budget;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + budget;
	result = prime * result + ((location == null) ? 0 : location.hashCode());
	result = prime * result + movieId;
	result = prime * result + ((movieName == null) ? 0 : movieName.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Movie other = (Movie) obj;
	if (budget != other.budget)
		return false;
	if (location == null) {
		if (other.location != null)
			return false;
	} else if (!location.equals(other.location))
		return false;
	if (movieId != other.movieId)
		return false;
	if (movieName == null) {
		if (other.movieName != null)
			return false;
	} else if (!movieName.equals(other.movieName))
		return false;
	return true;
}
@Override
public String toString() {
	return "Movie [movieId=" + movieId + ", movieName=" + movieName + ", location=" + location + ", budget=" + budget
			+ "]";
}


}
