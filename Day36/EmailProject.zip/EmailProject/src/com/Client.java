package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Client {
public static void main(String[] args) {
	ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
	Email email=context.getBean(Email.class);
	To to=(To)context.getBean(To.class);
	From from=context.getBean(From.class);
	Subject subject=context.getBean(Subject.class);
	Body body=context.getBean(Body.class);
	to.setToEmail("Me.gmail");
	to.setToName("Roshan");
	from.setFromEmail("Him.gmail");
	from.setFromName("Prem");
	subject.setCaption("Train");
	body.setMessage("Booked");
	System.out.println(email);
	
	
	
	
}
}
