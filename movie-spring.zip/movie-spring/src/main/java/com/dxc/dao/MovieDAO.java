package com.dxc.dao;

import java.util.List;

import com.dxc.model.Movie;

public interface MovieDAO {
public boolean addMovie(Movie movie);
public List<Movie> getAllMovies();
public Movie getMovie(int ticketId);
public boolean updateMovie(Movie movie);
public boolean deleteMovie(int ticketId);
}
