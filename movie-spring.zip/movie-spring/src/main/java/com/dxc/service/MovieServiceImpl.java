package com.dxc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dxc.dao.MovieDAO;
import com.dxc.model.Movie;
@Service
public class MovieServiceImpl implements MovieService {
	@Autowired
MovieDAO moviedao;
	@Override
	public boolean addMovie(Movie movie) {
		// TODO Auto-generated method stub
		return moviedao.addMovie(movie);
	}

	@Override
	public List<Movie> getAllMovies() {
		// TODO Auto-generated method stub
		return moviedao.getAllMovies();
	}

	@Override
	public Movie getMovie(int ticketId) {
		// TODO Auto-generated method stub
		return moviedao.getMovie(ticketId);
	}

	@Override
	public boolean updateMovie(Movie movie) {
		// TODO Auto-generated method stub
		return moviedao.updateMovie(movie);
	}

	@Override
	public boolean deleteMovie(int ticketId) {
		// TODO Auto-generated method stub
		return moviedao.deleteMovie(ticketId);
	}

}
