package com.dxc.model;

import org.springframework.data.annotation.Id;

public class Movie {
	@Id
private int ticketId;
private String movieName;
private String location;
private int budget;
public Movie() {
	// TODO Auto-generated constructor stub
}
public Movie(int ticketId, String movieName, String location, int budget) {
	super();
	this.ticketId = ticketId;
	this.movieName = movieName;
	this.location = location;
	this.budget = budget;
}
public int getTicketId() {
	return ticketId;
}
public void setTicketId(int ticketId) {
	this.ticketId = ticketId;
}
public String getMovieName() {
	return movieName;
}
public void setMovieName(String movieName) {
	this.movieName = movieName;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public int getBudget() {
	return budget;
}
public void setBudget(int budget) {
	this.budget = budget;
}
@Override
public String toString() {
	return "Movie [ticketId=" + ticketId + ", movieName=" + movieName + ", location=" + location
			+ ", budget=" + budget + "]";
}

}
