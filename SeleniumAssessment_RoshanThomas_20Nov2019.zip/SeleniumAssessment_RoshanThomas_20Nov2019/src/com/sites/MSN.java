package com.sites;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class MSN {
	public WebDriver driver;
	public String Browser="chrome";
	@Test
public void msn() throws InterruptedException{
		SoftAssert st=new SoftAssert();
		if(Browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");//we do this instead of setting system variables
			driver=new ChromeDriver(); //OpenBrowser
		}else if(Browser.equalsIgnoreCase("mozilla")){
			System.setProperty("webdriver.firefox.marionette", "geckodriver.exe");
			 driver=new FirefoxDriver();
		}else if(Browser.equalsIgnoreCase("ie")){
			System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
			 driver=new InternetExplorerDriver();
		}
		driver.get("https://www.msn.com/en-in/");
		driver.manage().window().maximize(); 
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//h3[contains(text(),'OneNote')]")).click();
		//get all the window references
		Set<String> windowHandles = driver.getWindowHandles();
		Iterator<String> i=windowHandles.iterator();
		  String msn = i.next();
		  String onenote=i.next();
		  //switch driver reference to onenote
		  driver.switchTo().window(onenote);
		  driver.findElement(By.xpath("//input[@id='i0116']")).sendKeys("87356");
		  Thread.sleep(2000);
		  //close oneNote window
		  driver.close();
		  //go to msn window
		  driver.switchTo().window(msn);
		  driver.findElement(By.xpath("//h3[contains(text(),'Skype')]")).click();
		  Thread.sleep(2000);
		  driver.quit();
}
	
}