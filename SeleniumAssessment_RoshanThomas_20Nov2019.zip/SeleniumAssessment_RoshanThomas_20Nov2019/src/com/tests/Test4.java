package com.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Test4 {
	public WebDriver driver;
	public String Browser="chrome";
	@Test
public void actiTimeTest1(){
		SoftAssert st=new SoftAssert();
		if(Browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");//we do this instead of setting system variables
			driver=new ChromeDriver(); //OpenBrowser
		}else if(Browser.equalsIgnoreCase("mozilla")){
			System.setProperty("webdriver.firefox.marionette", "geckodriver.exe");
			 driver=new FirefoxDriver();
		}else if(Browser.equalsIgnoreCase("ie")){
			System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
			 driver=new InternetExplorerDriver();
		}
		driver.get("http://localhost:9000/login.do");
		driver.manage().window().maximize(); 
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys("manager");
		driver.findElement(By.xpath("//a[@id='loginButton']")).click();
		driver.findElement(By.xpath("//a[@class='content tasks']//img[@class='sizer']")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Projects & Customers')]")).click();
		driver.findElement(By.xpath("//body/div[@id='container']/form[@id='customersProjectsForm']/table[@class='mainContentPadding rightPadding']/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td/input[2]")).click();
		WebElement customer = driver.findElement(By.xpath("//select[@name='customerId']"));
		Select sel=new Select(customer);
		sel.selectByValue("8");
		//type project Name
		driver.findElement(By.xpath("//input[@name='name']")).sendKeys("ProjectA");
		driver.findElement(By.xpath("//textarea[@name='description']")).sendKeys("DescriptionA");
		driver.findElement(By.xpath("//input[@id='active_projects_action']")).click();
		driver.findElement(By.xpath("//input[@name='createProjectSubmit']")).click();
		 driver.findElement(By.xpath("//span[@class='successmsg']")).isDisplayed();
		
			driver.findElement(By.xpath("//a[@id='logoutLink']")).click();
			st.assertAll();
		
		
		
	}
}
