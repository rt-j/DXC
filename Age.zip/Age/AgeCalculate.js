import React, { Component } from 'react'
import ButtonAge from './ButtonAge'
import InsertAge from './InsertAgeTb'

class AgeCalculate extends Component {
    constructor(props) {
        super(props)

        this.state = {
                 dates:'',
                 year:new Date(),
                 age:''
        }
    this.clicked=this.clicked.bind(this)
    }
clicked(event){
    event.preventDefault()
    const value = event.target.value
   
    switch(value){
        case 'Calculate':{
            
            var d=new Date(this.state.dates).toLocaleDateString()
            var dq=new Date(d).valueOf()
            var diff=(this.state.year.valueOf())-dq
            var ageCalculated=parseInt((diff/(1000*60*60*24*365)))
            this.setState({
                age:ageCalculated
            })
            break;
        }
            case 'Delete': {
                var str = this.state.dates;
                
                str = str.substr(0, str.length - 1);
                
                this.setState({ dates: str });
                break;
            }
            case 'Clear': {
                this.setState({ 
                    dates: ''
            });
                break;
            }
            default:
            this.setState({
                dates:this.state.dates += value
            })
    }
}

    render() {
        return (
            <div>
                <h1>Age Calculator</h1>
                <h2>Enter DOB In MM/DD/YYYY</h2>
               <h3>Todays Date:{this.state.year.valueOf()}</h3> 
                <InsertAge date={this.state.dates}/>
                
                 <div className="button-row">
                            <ButtonAge clicked={this.clicked} label={'Clear'} />
                            <ButtonAge clicked={this.clicked} label={'Delete'} />
                            
                            
                        </div>
                        <div className="button-row">
                            <ButtonAge clicked={this.clicked} label={'7'} />
                            <ButtonAge clicked={this.clicked} label={'8'} />
                            <ButtonAge clicked={this.clicked} label={'9'} />
                             
                        </div>
                        <div className="button-row">
                            <ButtonAge clicked={this.clicked} label={'4'} />
                            <ButtonAge clicked={this.clicked} label={'5'} />
                            <ButtonAge clicked={this.clicked} label={'6'} />
                             
                        </div>
                        <div className="button-row">
                            <ButtonAge clicked={this.clicked} label={'1'} />
                            <ButtonAge clicked={this.clicked} label={'2'} />
                            <ButtonAge clicked={this.clicked} label={'3'} />
                            
                        </div>
                        <div className="button-row">
                            <ButtonAge clicked={this.clicked} label={'0'} />
                            <ButtonAge clicked={this.clicked} label={'/'} />
                             
                        </div>
                        <div>
                            <ButtonAge clicked={this.clicked} label={'Calculate'}/>
                        </div>
                       <span>Age is {this.state.age}</span>
            </div>
        )
    }
}

export default AgeCalculate
