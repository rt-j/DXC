import React from 'react';
const InsertAge=(props)=>{
return(
    <div>
        <input type="text" readOnly value={props.date}/>
    </div>
)
}
export default InsertAge