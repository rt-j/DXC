import React, { Component } from 'react'

const ButtonAge = (props) => {
    return (
        <input type="button" value={props.label} onClick = {props.clicked} />
        
    );
}

export default ButtonAge
