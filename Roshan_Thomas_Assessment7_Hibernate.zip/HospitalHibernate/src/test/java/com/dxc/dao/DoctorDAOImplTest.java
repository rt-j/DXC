package com.dxc.dao;

import java.util.ArrayList;
import java.util.List;

import com.dxc.model.Doctor;
import com.dxc.model.HospitalDetails;

import junit.framework.TestCase;

public class DoctorDAOImplTest extends TestCase {
	DoctorDAO dImpl;
@Override
protected void setUp() throws Exception {
	// TODO Auto-generated method stub
	super.setUp();
	dImpl=new DoctorDAOImpl();
}
	public void testAddDoctor() {
		List<Doctor> allDoctor1=dImpl.getAllDoctors();
		HospitalDetails hos=new HospitalDetails("KG", "MUM");
		List<HospitalDetails> allDetails=new ArrayList();
		allDetails.add(hos);
		Doctor doctor=new Doctor(1,"Kartick",450,allDetails);
		dImpl.addDoctor(doctor);
		System.out.println(doctor);
		List<Doctor> allDoctor=dImpl.getAllDoctors();
		assertNotSame(allDoctor1.size(), allDoctor.size());
		}

	
	
	
	  public void testGetAllDoctors() { 
		  List<Doctor> doctors=dImpl.getAllDoctors();
	  assertNotNull(doctors); 
	  }
	  
	
	  public void testGetSingleDoctor() { 
		  Doctor doctor=dImpl.getSingleDoctor(1);
	  assertEquals("Kartick", doctor.getName());
	  }
	  
	  
	  public void testUpdateDoctor() {
			HospitalDetails details=new HospitalDetails("Ty", "iut");
			List<HospitalDetails> hospitalList=new ArrayList();
			hospitalList.add(details);
			Doctor doctor=new Doctor(2, "2424", 1324, hospitalList);
			dImpl.addDoctor(doctor);
			HospitalDetails updateDetails=new HospitalDetails("111", "1111");
			List<HospitalDetails> updatelist=new ArrayList();
			updatelist.add(updateDetails);
			Doctor updateDoctor=new Doctor(2, "Cfg", 1324, updatelist);
			dImpl.updateDoctor(updateDoctor);
			Doctor getDoctor=dImpl.getSingleDoctor(2);
			assertEquals(getDoctor.getName(), updateDoctor.getName());
			
		}
	  
	  public void testDeleteDoctor() {
	  
	  List<Doctor> before=dImpl.getAllDoctors(); 
	  dImpl.deleteDoctor(1);
	  List<Doctor> after=dImpl.getAllDoctors();
	  assertEquals(before.size(),after.size()-1); 
	  }
	  
	  public void testGetDoctorByName() {
		  HospitalDetails details=new HospitalDetails("KMCH", "Chennai");
		  List<HospitalDetails> hospitalList=new ArrayList();
		  Doctor d=new Doctor(3, "Jim", 890, hospitalList);
		  dImpl.addDoctor(d);
		  List<Doctor> list1=new ArrayList();
		  list1.add(d);
		  List<Doctor> doctorsList=dImpl.getDoctorByName("Jim");
		  
		  assertEquals(d, doctorsList);
		  
	  }
	 
	 
	  

}
