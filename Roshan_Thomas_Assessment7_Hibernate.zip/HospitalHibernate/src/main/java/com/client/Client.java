package com.client;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.dao.DoctorDAO;
import com.dxc.dao.DoctorDAOImpl;
import com.dxc.model.Doctor;
import com.dxc.model.HospitalDetails;
import com.dxc.util.HibernateUtil;

public class Client {
public static void main(String[] args) {
	
	HospitalDetails hos=new HospitalDetails("K","CBE");
	
		/*
		 * List<HospitalDetails> l; l.add(hos); Doctor d=new Doctor(1, "KTY", 890, l);
		 * DoctorDAO d=new DoctorDAOImpl(); //d.addDoctor(d);
		 */	
	
}
}
