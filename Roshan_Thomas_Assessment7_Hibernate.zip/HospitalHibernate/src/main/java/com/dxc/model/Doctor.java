package com.dxc.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.search.annotations.IndexedEmbedded;

@Entity
public class Doctor {
	@Id
private int id;
private String name;
private int fees;
@IndexedEmbedded
@ElementCollection
private List<HospitalDetails> hospitalDetails;
public Doctor() {
	// TODO Auto-generated constructor stub
}
public Doctor(int id, String name, int fees, List<HospitalDetails> hospitalDetails) {
	super();
	this.id = id;
	this.name = name;
	this.fees = fees;
	this.hospitalDetails = hospitalDetails;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getFees() {
	return fees;
}
public void setFees(int fees) {
	this.fees = fees;
}
public List<HospitalDetails> getHospitalDetails() {
	return hospitalDetails;
}
public void setHospitalDetails(List<HospitalDetails> hospitalDetails) {
	this.hospitalDetails = hospitalDetails;
}
@Override
public String toString() {
	return "Doctor [id=" + id + ", name=" + name + ", fees=" + fees + ", hospitalDetails=" + hospitalDetails + "]";
}



}
