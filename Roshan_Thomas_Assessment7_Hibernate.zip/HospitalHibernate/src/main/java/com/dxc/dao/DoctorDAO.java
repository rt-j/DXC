package com.dxc.dao;

import java.util.List;

import com.dxc.model.Doctor;

public interface DoctorDAO {
public void addDoctor(Doctor doctor);
public List<Doctor> getAllDoctors();
public Doctor getSingleDoctor(int id);
public void updateDoctor(Doctor doctor);
public void deleteDoctor(int id);
public List<Doctor> getDoctorByName(String name);
}
