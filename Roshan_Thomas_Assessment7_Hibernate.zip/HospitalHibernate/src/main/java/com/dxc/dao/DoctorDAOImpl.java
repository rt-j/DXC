package com.dxc.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.model.Doctor;
import com.dxc.util.HibernateUtil;

public class DoctorDAOImpl implements DoctorDAO {
	SessionFactory factory=HibernateUtil.getSessionFactory();

	public void addDoctor(Doctor doctor) {
		// TODO Auto-generated method stub
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(doctor);
		transaction.commit();
		session.close();

	}

	public List<Doctor> getAllDoctors() {
		// TODO Auto-generated method stub
		Session session=factory.openSession();
		Query q=session.createQuery("from Doctor");
		
		return q.list();
	}

	public Doctor getSingleDoctor(int id) {
		// TODO Auto-generated method stub
		Session session=factory.openSession();
		Doctor d=(Doctor) session.get(Doctor.class, id);;
		return d;
	}

	public void updateDoctor(Doctor doctor) {
		// TODO Auto-generated method stub
		Session session=factory.openSession();
		Transaction trans=session.beginTransaction();
		session.update(doctor);
		trans.commit();
		session.close();

	}

	public void deleteDoctor(int id) {
		// TODO Auto-generated method stub
		Session session=factory.openSession();
		Transaction t=session.beginTransaction();
		Doctor deleteDoctor=(Doctor) session.get(Doctor.class, id);
		session.delete(deleteDoctor);
		t.commit();
		session.close();

	}

	public List<Doctor> getDoctorByName(String name) {
		// TODO Auto-generated method stub
		Session session=factory.openSession();
		Query q=session.createQuery("from Doctor where name='"+name+"'");
		return q.list();
	}

}
