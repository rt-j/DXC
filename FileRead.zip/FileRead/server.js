var http = require("http");
var url = require("url")
var files=require("fs")

function start(portNumber, route, handle) {
    function onRequest(request, response) {
      
        var pathname = url.parse(request.url).pathname
        if (request.url === '/favicon.ico') {
            response.writeHead(200, { 'Content-Type': 'image/x-icon' });
            return;
        }
        console.log("Server  has started on port number : " + portNumber)
        //route(pathname,handle,response)
        //response.end();
        console.log("I have recvd : "+pathname)
        var allMyData=""
        var count=0;
        
        request.setEncoding("utf8")
        request.addListener("data",function(dd){
            allMyData+=dd;
            console.log("###Received chunk"+dd)
            count++
            console.log(count)
            files.writeFileSync('./File'+count,dd)
            
        })                                      //dd is chunk data
        request.addListener("end",function(){  //after everything we are routing
            route(pathname,handle,response,allMyData);
        })
    }
    var server = http.createServer(onRequest)
    server.listen(portNumber);
    console.log("Server started on :"+portNumber)
}
exports.start = start