package com.dxc.uf.dao;

import com.dxc.uf.model.UserForm;

public interface UserFormDao {
	public void addUser(UserForm userForm);
	public boolean validateUser(String username,String password);
}
