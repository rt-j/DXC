package com.dxc.uf.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dxc.uf.dbcon.GetDB;
import com.dxc.uf.model.UserForm;

public class UserformDaoImpl implements UserFormDao {
	private static  final String INSERT="insert into userform values(?,?,?,?)";
	private static final String CHECK="select * from userform where name=? and password=?";
	Connection connection=GetDB.getConnection();
	UserForm u=new UserForm();

	@Override
	public void addUser(UserForm userForm) {
		// TODO Auto-generated method stub
		
		try {
			PreparedStatement ps;
			ps = connection.prepareStatement(INSERT);
			ps.setString(1,userForm.getUsername() );
			ps.setString(2,userForm.getPassword() );
			ps.setString(3,userForm.getQualification() );
			ps.setString(4,userForm.getGender() );
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public boolean validateUser(String username, String password) {
		boolean t=false;
		
		try {
			PreparedStatement ps1;
			ps1 = connection.prepareStatement(CHECK);
			ps1.setString(1,username );
			ps1.setString(2, password);
			ResultSet r=ps1.executeQuery();
			if(r.next())
				t=true;
			else
				t=false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return t;
	}

}
