package com.dxc.uf.model;

public class UserForm {
public String username;
public String password;
public String qualification;
public String gender;
public UserForm(String username, String password, String qualification, String gender) {
	super();
	this.username = username;
	this.password = password;
	this.qualification = qualification;
	this.gender = gender;
}
public UserForm() {
	// TODO Auto-generated constructor stub
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getQualification() {
	return qualification;
}
public void setQualification(String qualification) {
	this.qualification = qualification;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
@Override
public String toString() {
	return "UserForm [username=" + username + ", password=" + password + ", qualification=" + qualification
			+ ", gender=" + gender + "]";
}

}
