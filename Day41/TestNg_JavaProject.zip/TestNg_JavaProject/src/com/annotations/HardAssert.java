package com.annotations;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

public class HardAssert {
	@Test
	public void testCase1(){
		int ex=10;
		int ac=0;
		System.out.println("Before check");
		try{
		assertEquals(ac, ex);
		}catch(Throwable t){
			System.out.println("Within try catch");
		}
		System.out.println("After check");
	}//if we give try catch then even if there is error the test cases passess and the statements after the try-catch is also executed.
}


