package com.annotations;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class SoftAssertEx {
@Test
public void testCase1(){
	SoftAssert s=new SoftAssert();
	int ex=10;
	int ac=0;
	System.out.println("Before Check");
	s.assertEquals(ac, ex);
	System.out.println("Before assert equals");
	s.assertAll();
	System.out.println("After assertALl");
}
}
