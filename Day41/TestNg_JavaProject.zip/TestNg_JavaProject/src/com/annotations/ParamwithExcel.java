package com.annotations;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import xls.ShineXlsReader;

public class ParamwithExcel {
	@Test(dataProvider="setOfData")
 public void readParams(String name,String passowrd){
	 ShineXlsReader shineXlsReader = new ShineXlsReader("TestData.xlsx");
	 int rcount=shineXlsReader.getRowCount("Sheet1");
	 int columnCount=shineXlsReader.getColumnCount("Sheet1");
	 System.out.println(name+" "+passowrd);
	 
 }
	@DataProvider
	public Object[][] setOfData(){
		ShineXlsReader s=new ShineXlsReader("TestData.xlsx");
		int rowCount = s.getRowCount("Sheet1");
		int columnCount = s.getColumnCount("Sheet1");
		Object object[][] =new Object[rowCount-1][columnCount];
		for(int i=2;i<rowCount;i++){
			for(int j=0;j<columnCount;j++){
				object[i-2][j]=s.getCellData("Sheet1", j, i);
		}
	}
		return object;
}
}
