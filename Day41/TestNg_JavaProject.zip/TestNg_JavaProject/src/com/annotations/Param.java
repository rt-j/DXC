package com.annotations;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Param {
	@Test(dataProvider="getdata1")
	public void testCase1(String cn,String cp){
		System.out.println("Name is"+cn+"Password is"+cp);
}
	@Test
	public void testCase2(String name,String password){
		name="King";
		password="Kohli";
		System.out.println("Name2 is"+name+"Pass2 is"+password);
	}
	@DataProvider
	public Object[][] getdata1(){
		Object obj[][]=new Object[3][2];
		obj[0][0]="Roshan";
		obj[0][1]="12";
		obj[1][0]="Prem";
		obj[1][1]="1245";
		obj[2][0]="Shelby";
		obj[2][1]="9876";
		return obj;
	}
}
