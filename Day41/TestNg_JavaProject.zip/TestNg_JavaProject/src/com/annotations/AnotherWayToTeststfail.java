package com.annotations;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class AnotherWayToTeststfail {
	@Test
public void testcase1(){
	SoftAssert s=new SoftAssert();
	String ex="Chennai";
	String ac="Madras";
	if(ex.equals(ac)){
      s.fail("Not matched");
}
	System.out.println("After");
	s.assertAll();
	System.out.println("After assert");
}
}
