package com.annotations;

import org.testng.annotations.Test;

public class Order {
	@Test
	public void create(){
System.out.println("small c");
}
@Test
public void Add(){
	System.out.println("Add");
}
@Test(priority=-1)
public void add(){
	System.out.println("Small add");
	
}
}
