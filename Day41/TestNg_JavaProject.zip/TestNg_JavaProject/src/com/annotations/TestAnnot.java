package com.annotations;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestAnnot {

	@Test
	public void testCase1() {
		System.out.println("Compose Mail");
	}
	@Test
	public void testCase2() {
		System.out.println("Delete Mail");
	}
	@BeforeMethod
	public void befMethod(){
		System.out.println("Login");
	}
	@AfterMethod
	public void afMethod(){
		System.out.println("Logout");
	}
	@BeforeClass
	public void b4Class(){
		System.out.println("Start server");
	}
	@AfterClass
	public void atClass(){
		System.out.println("Stop Server");
	}
}
