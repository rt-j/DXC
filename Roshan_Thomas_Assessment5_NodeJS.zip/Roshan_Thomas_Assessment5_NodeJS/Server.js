var express = require("express");
var app = express();
var fs=require("fs")
var data=fs.readFileSync("./resources/about.txt","utf-8")
//var todoController=require("./resources/about.txt")
//set up template engine
app.set("view engine", "ejs");
//static files

//todoController(app)
//listen to port
app.listen(3000);
console.log("You are listening to port 3000");
app.get('/about', function (request, response) 
{ 
    //response.send("TODO GET")
    response.render("about",{
        comapanydatas:data
    })
})
